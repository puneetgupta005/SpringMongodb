package com.blnqr.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLFileConstants.
 */
public interface BLFileConstants {
	
	/** The file not passed error. */
	public static  String FILE_NOT_PASSED_ERROR="No file is passed in the request";
	
	/** The blnqid not passed error. */
	public static  String BLNQID_NOT_PASSED_ERROR="No blnqId is passed in the request";
	
	/** The option not passed error. */
	public static  String OPTION_NOT_PASSED_ERROR="No option is passed in the request";
	
	/** The option invalid. */
	public static  String OPTION_INVALID="Invalid Option is passed in the request";
	
	/** The file upload error. */
	public static  String FILE_UPLOAD_ERROR="Error is uploading file in the database";
	
	/** The fileid not passed error. */
	public static  String FILEID_NOT_PASSED_ERROR="No fileId is passed in the request";
	
	/** The file not updated error. */
	public static  String FILE_NOT_UPDATED_ERROR="Unable to update file";
	
	/** The file not found error. */
	public static  String FILE_NOT_FOUND_ERROR="No such file exists.";
	
	/** The file not deleted error. */
	public static  String FILE_NOT_DELETED_ERROR="Unable to delete file";
}
