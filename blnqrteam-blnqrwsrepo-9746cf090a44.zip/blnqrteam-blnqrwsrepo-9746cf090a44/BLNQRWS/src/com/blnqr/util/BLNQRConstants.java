package com.blnqr.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLNQRConstants.
 */
public interface BLNQRConstants {

	/** The Constant BLNQR_ID. */
	public final static String BLNQR_ID = "ID";
	
	/** The Constant BLNQR_MESSAGE. */
	public final static String BLNQR_MESSAGE = "message";
	
	/** The Constant BLNQR_CREATE_FAILED_MESSAGE. */
	public final static String BLNQR_CREATE_FAILED_MESSAGE = "Error while creating BLNQR";
	
	/** The Constant BLNQR_CREATE_SUCCESS. */
	public final static String BLNQR_CREATE_SUCCESS = "BLNQR created successfully";
	
	/** The Constant BLNQR_FETCH_FAILED. */
	public final static String BLNQR_FETCH_FAILED = "Error getting BLNQR";
	
	/** The Constant BLNQR_NAME_NULL. */
	public final static String BLNQR_NAME_NULL = "Invalid request, blnqr name is null";
	
	
	/** The Constant BLNQR_NOT_FOUND. */
	public final static String BLNQR_ID_NULL = "Invalid request, blnqrID is null";
	public final static String BLNQR_NOT_FOUND = "BLNQR not found";
	
	/** The Constant BLNQR_ALREADY_EXISTS. */
	public final static String BLNQR_ALREADY_EXISTS = "BLNQR with the same name already exists";
	
	/** The Constant BLNQR_ID_AND_NAME_AND_LOCATION_NULL. */
	public static final String BLNQR_ID_AND_NAME_AND_LOCATION_NULL = "BLNQR id, name and location are not defined";
	
	/** The Constant BLNQR_ID_AND_NAME_AND_LOCATION_VALUE_NULL. */
	public static final String BLNQR_ID_AND_NAME_AND_LOCATION_VALUE_NULL = "BLNQR id, name and location values are not defined";
	
	/** The Constant BLNQR_ID_AND_NAME_NULL. */
	public static final String BLNQR_ID_AND_NAME_NULL = "BLNQR ID or name cannot be null.";
	
	/** The Constant BLNQR_UPDATE_SUCESS. */
	public static final Object BLNQR_UPDATE_SUCESS = "BLNQR Updated Successfully.";
	
	/** The Constant BLNQR_UPDATE_FAILED. */
	public static final Object BLNQR_UPDATE_FAILED = "BLNQR Updated Failed.";
	
	/**
	 * The Constant BLNQR feedback null 
	 */
	
	public static final String BLNQR_FEEDBACK_NULL = "BLNQR feedback is not passed";
	
	/**
	 * The Constant BLNQR message null
	 * 
	 */
	public static final String BLNQR_MESSAGE_NULL = "BLNQR message not passed";
}
