package com.blnqr.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface BlnqConstants.
 */
public interface BlnqConstants {
	
	/** The file not found. */
	public static  String FILE_NOT_FOUND="NO such file exists in the database with Id ";
	
	/** The blnq create error. */
	public static  String BLNQ_CREATE_ERROR="Unable to create blnq";
	
	/** The blnqid not passed error. */
	public static  String BLNQID_NOT_PASSED_ERROR="No blnqId is passed in the request";
	
	/** The blnqr not passed error. */
	public static  String BLNQR_NOT_PASSED_ERROR="No blnqr is passed in the request";
	
	/** The contexttype not passed error. */
	public static  String CONTEXTTYPE_NOT_PASSED_ERROR="No blnqContextType is passed in the request";
	
	/** The question not passed error. */
	public static  String QUESTION_NOT_PASSED_ERROR="No blnqQuestion is passed in the request";
	
	/** The option1 not passed error. */
	public static  String OPTION1_NOT_PASSED_ERROR="No blnqOption1 is passed in the request";
	
	/** The option2 not passed error. */
	public static  String OPTION2_NOT_PASSED_ERROR="No blnqOption1 is passed in the request";
	
	/** The createdby not passed error. */
	public static  String CREATEDBY_NOT_PASSED_ERROR="No blnqcreateBy is passed in the request";
	
	/** The modifiedby not passed error. */
	public static  String MODIFIEDBY_NOT_PASSED_ERROR="No blnqLastModifiedBy is passed in the request";
	
	/** The blnq not updated error. */
	public static  String BLNQ_NOT_UPDATED_ERROR="Unable to update blinq";
	
	/** The blnq not found error. */
	public static  String BLNQ_NOT_FOUND_ERROR="No such blnq exists.";
	
	/** The blnq not deleted error. */
	public static  String BLNQ_NOT_DELETED_ERROR="Unable to delete blnq";
	

}
