package com.blnqr.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLNQConstants.
 */
public interface BLNQConstants {

	/** The Constant BLNQ_MESSAGE. */
	public static  String FILE_NOT_FOUND="NO such file exists in the database with Id ";
	
	/** The blnq create error. */
	public static  String BLNQ_CREATE_ERROR="Unable to create blnq";
	
	/** The blnqid not passed error. */
	public static  String BLNQID_NOT_PASSED_ERROR="No blnqId is passed in the request";
	
	/** The blnqr not passed error. */
	public static  String BLNQR_NOT_PASSED_ERROR="No blnqr is passed in the request";
	
	/** The contexttype not passed error. */
	public static  String CONTEXTTYPE_NOT_PASSED_ERROR="No blnqContextType is passed in the request";
	
	/** The question not passed error. */
	public static  String QUESTION_NOT_PASSED_ERROR="No blnqQuestion is passed in the request";
	
	/** The option1 not passed error. */
	public static  String OPTION1_NOT_PASSED_ERROR="No blnqOption1 is passed in the request";
	
	/** The option2 not passed error. */
	public static  String OPTION2_NOT_PASSED_ERROR="No blnqOption1 is passed in the request";
	
	/** The createdby not passed error. */
	public static  String CREATEDBY_NOT_PASSED_ERROR="No blnqcreateBy is passed in the request";
	public static  String FEEDBACK_NOT_PASSED_ERROR="No feeddback is passed in the request";
	
	/** The modifiedby not passed error. */
	public static  String MODIFIEDBY_NOT_PASSED_ERROR="No blnqLastModifiedBy is passed in the request";
	
	/** The blnq not updated error. */
	public static  String BLNQ_NOT_UPDATED_ERROR="Unable to update blinq";
	
	/** The blnq not found error. */
	public static  String BLNQ_NOT_FOUND_ERROR="No such blnq exists.";
	
	/** The blnq not deleted error. */
	public static  String BLNQ_NOT_DELETED_ERROR="Unable to delete blnq";
	
	/** The Constant BLNQ_NULL. */
	public final static String BLNQ_NULL = "BLNQ is null";
	
	/** The Constant BLNQ_ID. */
	public final static String BLNQ_ID = "ID";
	
	/** The Constant BLNQ_MESSAGE. */
	public final static String BLNQ_MESSAGE = "message";
	
	/** The Constant BLNQ_MISSING_ID. */
	public final static String BLNQ_MISSING_ID = "BLNQ ID is null";
	
	/** The Constant BLNQ_NOT_FOUND. */
	public final static String BLNQ_NOT_FOUND = "BLNQ you want to update/delete does not exists";
	
	/** The Constant BLNQ_UPDATED. */
	public final static String BLNQ_UPDATED = "BLNQ updated Successfully";
	
	/** The Constant BLNQ_OR_BLNQR_GET_ID_NULL. */
	public final static String BLNQ_OR_BLNQR_GET_ID_NULL = "Please Enter  BLNQ or BLNQR ID";
	
	/** The Constant BLNQ_ID_NOT_FOUND. */
	public final static String BLNQ_ID_NOT_FOUND  = "BLNQ not found";
	
	/** The Constant BLINQ_UPDATE_ERROR. */
	public final static String BLINQ_UPDATE_ERROR = "Error while updating BLNQ";
	
	/** The Constant BLNQ_CONTEXT_IMAGE. */
	public final static String BLNQ_CONTEXT_IMAGE = "image";
	
	/** The Constant BLNQ_CONTEXT_TEXT. */
	public final static String BLNQ_CONTEXT_TEXT = "text";
	
	/** The Constant BLNQ_OPTION_IMG_1_NULL. */
	public final static String BLNQ_OPTION_IMG_1_NULL = "BLNQ optionImage1 detail not provided";
	
	/** The Constant BLNQ_OPTION_IMG_2_NULL. */
	public final static String BLNQ_OPTION_IMG_2_NULL = "BLNQ optionImage2 detail not provided";
	
	/** The Constant BLNQ_UNKNOWN_ERROR. */
	public final static String BLNQ_UNKNOWN_ERROR = "Some unkown error has accurred";
	

}
