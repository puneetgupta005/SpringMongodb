package com.blnqr.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

// TODO: Auto-generated Javadoc
/**
 * The Class HibernateUtil.
 */
public class HibernateUtil {
	
	/** The entity manager factory. */
	private static EntityManagerFactory entityManagerFactory;
	static{
		entityManagerFactory=Persistence.createEntityManagerFactory( "blnqr" );
	}
	
	/**
	 * Creates the entity manager.
	 *
	 * @return the entity manager
	 */
	public static EntityManager createEntityManager(){
		return entityManagerFactory.createEntityManager();
	}
	
	/**
	 * Close entity manager factory.
	 */
	public void closeEntityManagerFactory(){
		entityManagerFactory.close();
	}
}
