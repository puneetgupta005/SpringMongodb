package com.blnqr.webservice;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.Provider;

// TODO: Auto-generated Javadoc
/**
 * The Class AuthenticationFilter.
 */
@Provider

public class AuthenticationFilter implements ContainerRequestFilter {
	
	/** The Constant AUTHENTICATION_HEADER. */
	public static final String AUTHENTICATION_HEADER = "token";

	/* (non-Javadoc)
	 * @see javax.ws.rs.container.ContainerRequestFilter#filter(javax.ws.rs.container.ContainerRequestContext)
	 */
	@Override
	/**
	 * AuthenticationFilter for the token validation before actual resource
	 * @return  Redirect to the actual resource id success , authorization error if fail.
	 * @author Puneet Gupta
	 * @since 23-March-2017
	 *
	 */
	public void filter(ContainerRequestContext containerRequest)
			throws WebApplicationException {

		String authCredentials = containerRequest
				.getHeaderString(AUTHENTICATION_HEADER);
		

		// better injected
		String path= containerRequest.getUriInfo().getPath();
		String method=containerRequest.getMethod();
		if(path.contains("login")&&method.equalsIgnoreCase("post")){
			return; 
		}
		AuthenticationService authenticationService = new AuthenticationService();

		boolean authenticationStatus = authenticationService
				.authenticate(authCredentials);

		if (!authenticationStatus) {
			
			throw new WebApplicationException(Status.UNAUTHORIZED);
		}

	}
}

