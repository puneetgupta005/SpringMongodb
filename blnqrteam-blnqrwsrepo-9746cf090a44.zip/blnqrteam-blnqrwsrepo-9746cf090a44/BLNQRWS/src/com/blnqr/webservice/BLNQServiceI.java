package com.blnqr.webservice;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.blnqr.entity.BLNQ;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLNQServiceI.
 */
@Path("/blnq")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface BLNQServiceI {
	
	/**
	 * Creates the blnq.
	 *
	 * @param blnq the blnq
	 * @return the response
	 */
	public Response createBlnq(BLNQ blnq);
	
	/**
	 * Fetch blnq.
	 *
	 * @param id the id
	 * @return the response
	 */
	public Response fetchBlnq(String id);
	
	/**
	 * Update blnq.
	 *
	 * @param blnq the blnq
	 * @return the response
	 */
	public Response updateBlnq(BLNQ blnq);
	
	/**
	 * Delete blnq.
	 *
	 * @param blnq the blnq
	 * @return the response
	 */
	public Response deleteBlnq(BLNQ blnq);
}
