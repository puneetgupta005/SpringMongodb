package com.blnqr.webservice;


// TODO: Auto-generated Javadoc
/**
 * The Class AuthenticationService.
 */
public class AuthenticationService {
	
	/**
	 * Authenticate.
	 *
	 * @param authCredentials the auth credentials
	 * @return true, if successful
	/**
	 * AuthenticationService for the token validation
	 * @author Puneet Gupta
	 * @since 23-March-2017
	 *
	 */
	public boolean authenticate(String authCredentials) {
		boolean authenticationStatus=false;
		if (null == authCredentials)
			return false;
		if(authCredentials.equals("12345")){
			authenticationStatus=true;
		}
		return authenticationStatus;
	}
}