package com.blnqr.webservice;
import java.io.InputStream;
import java.util.Date;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.commons.io.IOUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONObject;
import com.blnqr.dao.BlnqFileDAOImpl;
import com.blnqr.entity.BLFILE;
import com.blnqr.util.BLFileConstants;

// TODO: Auto-generated Javadoc
/**
 * The Class BLFileServiceImpl.
 */
@Path("/file")

public class BLFileServiceImpl implements BLFileServiceI{
	
	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLFileServiceI#createBLFile(java.io.InputStream, org.glassfish.jersey.media.multipart.FormDataContentDisposition, org.glassfish.jersey.media.multipart.FormDataBodyPart)
	 */
	@Override
	@Path("/add")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * WebService for creating file object
	 *
	 * @return  Response object.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 * 
	 */
	public Response createBLFile(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail,@FormDataParam("file") final FormDataBodyPart body ) {
		BlnqFileDAOImpl dao=new BlnqFileDAOImpl();
		BLFILE blfile=new BLFILE();
		JSONObject json=new JSONObject();
		try {
			if(uploadedInputStream==null){
				
				json.accumulate("message",BLFileConstants.FILE_NOT_PASSED_ERROR );
				return Response.serverError().entity(json.toString()).build();
			}
			
			blfile.setFileCreateDate(new Date());
			blfile.setFileName(fileDetail.getFileName());
			blfile.setFileData(IOUtils.toByteArray(uploadedInputStream));
			blfile.setFileMimeType(body.getMediaType().toString());
			blfile.setFileSize(blfile.getFileData().length);
			blfile.setFileType(body.getMediaType().getSubtype());
			dao.createBlnqFile(blfile);
			//dao.createBlnqFile(blfile);
			if(blfile.getBlnqFileID()==null){
				json.accumulate("message", BLFileConstants.FILE_UPLOAD_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			json.accumulate("message", "File is successfully uploaded");
			json.accumulate("id", blfile.getBlnqFileID());
			return Response.ok(json.toString(),MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.accumulate("message", "Something Bad Happens");
			return Response.serverError().entity(json.toString()).build();
		} 
		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLFileServiceI#updateBLFile(java.io.InputStream, org.glassfish.jersey.media.multipart.FormDataContentDisposition, org.glassfish.jersey.media.multipart.FormDataBodyPart, java.lang.String)
	 */
	@Override
	@Path("/update")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * WebService for updating file object
	 * @return  Response object.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public Response updateBLFile(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail,@FormDataParam("file") final FormDataBodyPart body,@FormDataParam("fileId") String fileId ) {
		BlnqFileDAOImpl dao=new BlnqFileDAOImpl();
		BLFILE blfile=new BLFILE();
		JSONObject json=new JSONObject();
		try {
			if(uploadedInputStream==null){
				
				json.accumulate("message",BLFileConstants.FILE_NOT_PASSED_ERROR );
				return Response.serverError().entity(json.toString()).build();
			}
			if(fileId==null||fileId.length()==0){
				json.accumulate("message", BLFileConstants.FILEID_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			blfile.setFileCreateDate(new Date());
			blfile.setFileName(fileDetail.getFileName());
			blfile.setFileData(IOUtils.toByteArray(uploadedInputStream));
			blfile.setFileMimeType(body.getMediaType().toString());
			blfile.setFileSize(blfile.getFileData().length);
			blfile.setFileType(body.getMediaType().getSubtype());
			blfile.setBlnqFileID(fileId);
			if(!(dao.updateBlnqFile(blfile).equals(fileId))){
				json.accumulate("message", BLFileConstants.FILE_NOT_UPDATED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			json.accumulate("message", "File is successfully updated");
			json.accumulate("id", blfile.getBlnqFileID());
			return Response.ok(json.toString(),MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.accumulate("message", "Something Bad Happens");
			return Response.serverError().entity(json.toString()).build();
		} 
		

		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLFileServiceI#fetchBLFile(java.lang.String)
	 */
	@Override
	@Path("/{id}/get")
	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * WebService for fetching file object
	 * @return  Response object containing actual file in byte array .
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public Response fetchBLFile(@PathParam("id")String id) {
		BlnqFileDAOImpl dao=new BlnqFileDAOImpl();
		JSONObject json=new JSONObject();
		try{
			if(id==null||id.length()==0){
				
				json.accumulate("message",BLFileConstants.FILEID_NOT_PASSED_ERROR );
				return Response.serverError().entity(json.toString()).build();
			}
			BLFILE file=dao.fetchBlnqFile(id);
			if(file==null){
				json.accumulate("message",BLFileConstants.FILE_NOT_FOUND_ERROR);
				return Response.status(Response.Status.NOT_FOUND).entity(json.toString()).build();
			}
			String encode=org.apache.commons.codec.binary.Base64.encodeBase64String(file.getFileData());
			file.setFileData(null);
			json=new JSONObject(file);
			json.append("data", encode);
			//json.remove("fileData");
			/*FileOutputStream fos = new FileOutputStream("/home/supai/"+file.getBlnqFileID()+"."+file.getFileType());
			fos.write(file.getFileData());
			fos.close();*/
			//json.accumulate("file",file);
			return Response.ok(json.toString(),MediaType.APPLICATION_JSON).build();
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.accumulate("message", "Something Bad Happens");
			return Response.serverError().entity(json.toString()).build();
		}
		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLFileServiceI#deleteBLFile(java.lang.String)
	 */
	@Override
	@Path("/{id}/delete")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	/**
	 * WebService for Deleting file object
	 * @return  Response object.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public Response deleteBLFile(@PathParam("id")String id) {
		BlnqFileDAOImpl dao=new BlnqFileDAOImpl();
		JSONObject json=new JSONObject();
		try {
			if(id==null||id.length()==0){
				
				json.accumulate("message",BLFileConstants.FILEID_NOT_PASSED_ERROR );
				return Response.serverError().entity(json.toString()).build();
			}
			BLFILE file=dao.fetchBlnqFile(id);
			if(file==null){
				json.accumulate("message",BLFileConstants.FILE_NOT_FOUND_ERROR);
				return Response.status(Response.Status.NOT_FOUND).entity(json.toString()).build();
			}
			if(dao.deleteBlnqFile(file).equalsIgnoreCase("error")){
				json.accumulate("message", BLFileConstants.FILE_NOT_DELETED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			json.accumulate("message", "File is successfully deleted");
			
			return Response.ok(json.toString(),MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.accumulate("message", "Something Bad Happens");
			return Response.serverError().entity(json.toString()).build();
		}
	}

}
