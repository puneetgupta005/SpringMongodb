package com.blnqr.webservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONObject;

import com.blnqr.dao.BlnqrDAOImpl;
import com.blnqr.entity.BLNQR;
import com.blnqr.util.BLNQRConstants;

// TODO: Auto-generated Javadoc
/**
 * The Class BLNQRServiceImpl.
 */
@Path("/blnqr")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BLNQRServiceImpl implements BLNQRServiceI {

	/**
	 * {@link BLNQR}
	 *
	 * @author Amardeep Kumar
	 * @param blnqr the blnqr
	 * @return {@link Response}
	 * @since 21-march-2017
	 */
	@Path("/createBlnqr")
	@POST
	@Override
	public Response createBlnqr(BLNQR blnqr) {
		JSONObject jsonObject = new JSONObject();
		if(blnqr.getBlnqrName() == null || blnqr.getBlnqrName().trim().equals("")){
			jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_NAME_NULL);
			return Response.serverError().entity(jsonObject.toString()).build();
		}
		if(blnqr.getMessage() == null){
			jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_MESSAGE_NULL);
			return Response.serverError().entity(jsonObject.toString()).build();
		}
		if(blnqr.getFeedback() == null){
			jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_FEEDBACK_NULL);
			return Response.serverError().entity(jsonObject.toString()).build();
		}
		BlnqrDAOImpl blnqrDAOImpl = new BlnqrDAOImpl();
		BLNQR blnqrTemp =  blnqrDAOImpl.fetchBlnqr(null, blnqr.getBlnqrName(), null);
		if(blnqrTemp != null){
				jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_ALREADY_EXISTS);
				return Response.serverError().entity(jsonObject.toString()).build();
		}else{
			String id = blnqrDAOImpl.createBlnqr(blnqr);
			if(id != null){
				jsonObject.accumulate(BLNQRConstants.BLNQR_ID,id);
				jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_CREATE_SUCCESS);
				return Response.ok(jsonObject.toString(),MediaType.APPLICATION_JSON).build();
			}
			jsonObject.accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_CREATE_FAILED_MESSAGE);
			return Response.serverError().entity(jsonObject.toString()).build();
		}
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQRServiceI#updateBlnqr(com.blnqr.entity.BLNQR)
	 */
	@POST
	@Path("/updateBlnqr")
	@Override
	public Response updateBlnqr(BLNQR blnqr) {
		if(blnqr.getBlnqrID() == null || blnqr.getBlnqrID().trim().equals(""))
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_ID_NULL).toString()).build();
		if(blnqr.getBlnqrName() == null || blnqr.getBlnqrName().trim().equals(""))
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_NAME_NULL).toString()).build();
		if(blnqr.getMessage() == null)
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_MESSAGE_NULL).toString()).build();
		if(blnqr.getFeedback() == null)
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_FEEDBACK_NULL)).build();
		BLNQR mBlnqr =  new BlnqrDAOImpl().fetchBlnqr(blnqr.getBlnqrID(),null,null);
		if(mBlnqr != null){
				String mBlnqrId = new BlnqrDAOImpl().updateBlnqr(blnqr);
				if(mBlnqrId != null && mBlnqrId.trim().length() != 0) {
					return Response.ok().entity(new JSONObject().accumulate("id", mBlnqrId).accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_UPDATE_SUCESS).toString()).build();
				}
				else
					return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE,BLNQRConstants.BLNQR_UPDATE_FAILED)).build();
		}
		return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE,BLNQRConstants.BLNQR_UPDATE_FAILED)).build();
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQRServiceI#deleteBlnqr(com.blnqr.entity.BLNQR)
	 */
	@GET
	@Path("/delete")
	@Override
	public Response deleteBlnqr(BLNQR blinqr) {
		// TODO Auto-generated method stub
		return Response.status(200).entity("Deleteed").build();
	}

	
	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQRServiceI#fetchBlnqr(java.lang.String, java.lang.String, java.lang.String)
	 */
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	@Override
	public Response fetchBlnqr(@QueryParam("id") String id, @QueryParam("name") String name, @QueryParam("location") String location) {
		if(id == null && name == null && location == null) 
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE, BLNQRConstants.BLNQR_ID_AND_NAME_AND_LOCATION_NULL).toString()).build();
		else{
			if(id!=null&&id.trim().length()==0){
				id=null;
			}
			if(name!=null&&name.trim().length()==0){
				name=null;
			}
			if(location!=null&&location.trim().length()==0){
				location=null;
			}
		}
		
		BLNQR mBlnqr = new BlnqrDAOImpl().fetchBlnqr(id,name,location);
		if(mBlnqr == null) {
			return Response.serverError().entity(new JSONObject().accumulate(BLNQRConstants.BLNQR_MESSAGE,BLNQRConstants.BLNQR_NOT_FOUND).toString()).build();
		}
		return Response.ok().entity(new JSONObject(mBlnqr).toString()).build();
	}

}
