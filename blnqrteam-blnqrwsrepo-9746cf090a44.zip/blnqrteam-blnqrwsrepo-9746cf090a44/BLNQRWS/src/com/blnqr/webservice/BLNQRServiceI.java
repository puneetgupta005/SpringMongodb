package com.blnqr.webservice;

import javax.ws.rs.core.Response;

import com.blnqr.entity.BLNQR;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLNQRServiceI.
 */
public interface BLNQRServiceI {

	/**
	 * Creates the blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the response
	 */
	public Response createBlnqr(BLNQR blnqr);
	
	/**
	 * Fetch blnqr.
	 *
	 * @param id the id
	 * @param name the name
	 * @param location the location
	 * @return the response
	 */
	public Response fetchBlnqr(String id,String name,String location);
	
	/**
	 * Update blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the response
	 */
	public Response updateBlnqr(BLNQR blnqr);
	
	/**
	 * Delete blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the response
	 */
	public Response deleteBlnqr(BLNQR blnqr);
}
