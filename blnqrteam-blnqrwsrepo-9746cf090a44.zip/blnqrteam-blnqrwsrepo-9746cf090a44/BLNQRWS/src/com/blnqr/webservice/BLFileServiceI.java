package com.blnqr.webservice;

import java.io.InputStream;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

// TODO: Auto-generated Javadoc
/**
 * The Interface BLFileServiceI.
 */
public interface BLFileServiceI {
	
	/**
	 * Creates the BL file.
	 *
	 * @param uploadedInputStream the uploaded input stream
	 * @param fileDetail the file detail
	 * @param body the body
	 * @return the response
	 */
	public Response createBLFile(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail,@FormDataParam("file") final FormDataBodyPart body);
	
	/**
	 * Update BL file.
	 *
	 * @param uploadedInputStream the uploaded input stream
	 * @param fileDetail the file detail
	 * @param body the body
	 * @param fileId the file id
	 * @return the response
	 */
	public Response updateBLFile(@FormDataParam("file") InputStream uploadedInputStream,@FormDataParam("file") FormDataContentDisposition fileDetail,@FormDataParam("file") final FormDataBodyPart body,@FormDataParam("fileId") String fileId  );
	
	/**
	 * Fetch BL file.
	 *
	 * @param id the id
	 * @return the response
	 */
	public Response fetchBLFile(@PathParam("id")String id);
	
	/**
	 * Delete BL file.
	 *
	 * @param id the id
	 * @return the response
	 */
	public Response deleteBLFile(@PathParam("id")String id);

}
