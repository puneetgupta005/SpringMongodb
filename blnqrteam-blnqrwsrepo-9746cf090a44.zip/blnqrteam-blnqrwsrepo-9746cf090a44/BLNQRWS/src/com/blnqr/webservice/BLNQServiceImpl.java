package com.blnqr.webservice;
import java.util.Date;
import javax.ws.rs.core.Response;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import org.json.JSONObject;
import com.blnqr.dao.BlnqDAOImpl;
import com.blnqr.dao.BlnqFileDAOImpl;
import com.blnqr.dao.BlnqrDAOImpl;
import com.blnqr.entity.BLFILE;
import com.blnqr.entity.BLNQ;
import com.blnqr.entity.BLNQR;
import com.blnqr.util.BLNQConstants;
import com.blnqr.util.BLNQRConstants;
@Path("/blnq")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class BLNQServiceImpl implements BLNQServiceI {

	@Override
	@Path("/createBlnq")
	@POST
	/**
	 * 
	 * Create a BLNQ.
	 * {@link BLNQ}
	 * @param blnq
	 * @return {@link Response}
	 * @author Puneet Gupta
	 * @since 23-march-2017
	 */
	public Response createBlnq(BLNQ blnq) {
		BlnqDAOImpl dao=new BlnqDAOImpl();
		BlnqFileDAOImpl filedao=new BlnqFileDAOImpl();
		BlnqrDAOImpl blnqrdao=new BlnqrDAOImpl();
		JSONObject json=new JSONObject();
		try {
			//for complete validation
			if(blnq.getBlnqr().getBlnqrID()==null||blnq.getBlnqr().getBlnqrID().length()==0){
				json.accumulate("message", BLNQConstants.BLNQR_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqContextType()==null||blnq.getBlnqContextType().length()==0){
				json.accumulate("message", BLNQConstants.CONTEXTTYPE_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqOption1()==null||blnq.getBlnqOption1().length()==0){
				json.accumulate("message", BLNQConstants.OPTION1_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqOption2()==null||blnq.getBlnqOption2().length()==0){
				json.accumulate("message", BLNQConstants.OPTION2_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqcreateBy()==null||blnq.getBlnqcreateBy().length()==0){
				json.accumulate("message", BLNQConstants.CREATEDBY_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqLastModifiedBy()==null||blnq.getBlnqLastModifiedBy().length()==0){
				json.accumulate("message", BLNQConstants.MODIFIEDBY_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getFeedback()==null){
				json.accumulate("message", BLNQConstants.FEEDBACK_NOT_PASSED_ERROR);
				return Response.serverError().entity(json.toString()).build();
			}
			if(blnq.getBlnqContextType().equalsIgnoreCase("image")){
				BLFILE blfile=new BLFILE();
				blfile=filedao.fetchBlnqFile(blnq.getBlnqOption1ImgId().getBlnqFileID());
				if(blfile==null){
					json.accumulate("message", BLNQConstants.FILE_NOT_FOUND+blnq.getBlnqOption1ImgId());
					return Response.serverError().entity(json.toString()).build();
				}
				blnq.setBlnqOption1ImgId(blfile);
				blfile=filedao.fetchBlnqFile(blnq.getBlnqOption2ImgID().getBlnqFileID());
				if(blfile==null){
					json.accumulate("message",  BLNQConstants.FILE_NOT_FOUND+blnq.getBlnqOption2ImgID());
					return Response.serverError().entity(json.toString()).build();
				}
				blnq.setBlnqOption2ImgID(blfile);
			}
			blnq.setBlnqCreatedDate(new Date());
			blnq.setBlnqLastModifiedDate(new Date());
			BLNQR blnqr=blnqrdao.fetchBlnqr(blnq.getBlnqr().getBlnqrID());
			blnq.setBlnqr(blnqr);
			
			String blinqId=dao.createBlnq(blnq);
			if(blinqId==null){
				json.accumulate("message",  "Unable to add blnq");
				return Response.serverError().entity(json.toString()).build();
			}
			json.accumulate("id", blinqId);
			json.put("message",  "Blnq is successfully created");
			
			return Response.ok(json.toString(),MediaType.APPLICATION_JSON).build();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			json.accumulate("message", "Something Bad Happend");
			return Response.serverError().entity(json.toString()).build();
		}
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQServiceI#fetchBlnq(java.lang.String)
	 */
	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	@Override
	public Response fetchBlnq(@QueryParam("id")  String id) {
		if( id == null) 
			return Response.serverError().entity(new JSONObject().accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_OR_BLNQR_GET_ID_NULL).toString()).build();
		else if(id.length() == 0)
			return Response.serverError().entity(new JSONObject().accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_OR_BLNQR_GET_ID_NULL).toString()).build();
		BLNQ mBlnq = new BlnqDAOImpl().fetchBlnq(id);
		if(mBlnq == null)		 
			return Response.serverError().entity(new JSONObject().accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_ID_NOT_FOUND).toString()).build();
		return Response.ok().entity(new JSONObject(mBlnq).toString()).build();
	}

	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQServiceI#updateBlnq(com.blnqr.entity.BLNQ)
	 */
	
	
	/**
	 * Update an existing BLNQ entity
	 * @return {@link Response}
	 * @param blnq - BLNQ to be updated
	 * @author Amardeep Kumar
	 * @since 23-March-2017
	 */
	@Path("updateBlnq")
	@Override
	@POST
	public Response updateBlnq(BLNQ blnq) {
		JSONObject jsonObject = new JSONObject();
		BlnqDAOImpl blnqDao=new BlnqDAOImpl();
		BlnqFileDAOImpl filedao=new BlnqFileDAOImpl();
		try{
			if(blnq == null){
				jsonObject.put(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_NULL);
				return Response.serverError().entity(jsonObject.toString()).build();
			}else  if(blnq.getBlnqID() == null || blnq.getBlnqID().isEmpty()){
				jsonObject.put(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_MISSING_ID);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqr() == null){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQR_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}else if(blnq.getBlnqr().getBlnqrID() == null || blnq.getBlnqID().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQRConstants.BLNQR_ID_NULL);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqContextType()==null || blnq.getBlnqContextType() == null || blnq.getBlnqContextType().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.CONTEXTTYPE_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqOption1()==null || blnq.getBlnqOption1().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.OPTION1_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqOption2()==null || blnq.getBlnqOption2().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.OPTION2_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqcreateBy()==null || blnq.getBlnqcreateBy().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.CREATEDBY_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqLastModifiedBy()==null || blnq.getBlnqLastModifiedBy().isEmpty()){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.MODIFIEDBY_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getFeedback() == null){
				jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.FEEDBACK_NOT_PASSED_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnq.getBlnqContextType().equalsIgnoreCase(BLNQConstants.BLNQ_CONTEXT_IMAGE)){
				BLFILE blfile=new BLFILE();
				if(blnq.getBlnqOption1ImgId() == null || blnq.getBlnqOption1ImgId().getBlnqFileID() == null || blnq.getBlnqOption1ImgId().getBlnqFileID().isEmpty()){
					jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_OPTION_IMG_1_NULL);
					return Response.serverError().entity(jsonObject.toString()).build();
				}else if(blnq.getBlnqOption2ImgID() == null || blnq.getBlnqOption2ImgID().getBlnqFileID() == null ||  blnq.getBlnqOption1ImgId().getBlnqFileID().isEmpty()){
					jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_OPTION_IMG_2_NULL);
					return Response.serverError().entity(jsonObject.toString()).build();
				}
				blfile=filedao.fetchBlnqFile(blnq.getBlnqOption1ImgId().getBlnqFileID());
				if(blfile==null){
					jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.FILE_NOT_FOUND+blnq.getBlnqOption1ImgId().getBlnqFileID());
					return Response.serverError().entity(jsonObject.toString()).build();
				}
				blnq.setBlnqOption1ImgId(blfile);
				blfile=filedao.fetchBlnqFile(blnq.getBlnqOption2ImgID().getBlnqFileID());
				if(blfile==null){
					jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE,  BLNQConstants.FILE_NOT_FOUND+blnq.getBlnqOption2ImgID().getBlnqFileID());
					return Response.serverError().entity(jsonObject.toString()).build();
				}
				blnq.setBlnqOption2ImgID(blfile);
			}
			blnq.setBlnqCreatedDate(new Date());
			blnq.setBlnqLastModifiedDate(new Date());
			String blnqId = blnq.getBlnqID();
			BLNQ blnqTemp = null;
			blnqTemp = blnqDao.fetchBlnq(blnqId);
			if(blnqTemp == null){
				jsonObject.put(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_NOT_FOUND);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
			if(blnqDao.updateBlnq(blnq) !=null){
				jsonObject.put(BLNQConstants.BLNQ_ID, blnq.getBlnqID());
				jsonObject.put(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_UPDATED);
				return Response.ok(jsonObject.toString(),MediaType.APPLICATION_JSON).build();
			}else{
				jsonObject.put(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLINQ_UPDATE_ERROR);
				return Response.serverError().entity(jsonObject.toString()).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			jsonObject.accumulate(BLNQConstants.BLNQ_MESSAGE, BLNQConstants.BLNQ_UNKNOWN_ERROR);
			return Response.serverError().entity(jsonObject.toString()).build();
		}
	}

	
	/* (non-Javadoc)
	 * @see com.blnqr.webservice.BLNQServiceI#deleteBlnq(com.blnqr.entity.BLNQ)
	 */
	@Override
	public Response deleteBlnq(BLNQ blnq) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
