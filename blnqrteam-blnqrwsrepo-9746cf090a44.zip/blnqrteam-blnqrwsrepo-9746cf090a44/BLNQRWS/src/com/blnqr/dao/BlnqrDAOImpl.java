package com.blnqr.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.hibernate.Hibernate;
import com.blnqr.entity.BLNQ;
import com.blnqr.entity.BLNQR;
import com.blnqr.util.HibernateUtil;



 

// TODO: Auto-generated Javadoc
/**
 * The Class BlnqrDAOImpl.
 */
public class BlnqrDAOImpl implements BlnqrDAOI {
	
	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqrDAOI#createBlnqr(com.blnqr.entity.BLNQR)
	 */
	@Override
	public String createBlnqr(BLNQR blnqr) {
		EntityManager entityManager = null;
		try{
				  entityManager = HibernateUtil.createEntityManager();
				  entityManager.getTransaction().begin();
				  entityManager.persist(blnqr);
				  entityManager.getTransaction().commit();
				  return blnqr.getBlnqrID();
		}catch(Exception e){
			return null;
		}finally{
			if(entityManager.isOpen())
				entityManager.close();
		}
		
	}

	
	
	
	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqrDAOI#fetchBlnqr(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public BLNQR fetchBlnqr(String id, String name, String location) {
		EntityManager entityManager = null;
		entityManager = HibernateUtil.createEntityManager();
		try{
			if(id == null && name == null && location == null){ 
				return null;
			}
			String query="from BLNQR where ";
			if(id!=null){
				query+="blnqrID=:id and ";
			}
			if(name!=null){
				query+="blnqrName=:name and ";
			}
			if(location!=null){
				query+="blnqrLocation=:location ";
			}
			String s=query.trim();
			s=query.substring(s.length()-3,s.length());
			if(s.equalsIgnoreCase("and")){
				query=query.trim();
				query=query.substring(0,query.length()-3)+" ";
			}
			BLNQR mBlnqr = null;
			Query q =  entityManager.createQuery(query,BLNQR.class);
			if(id!=null){
				q.setParameter("id",id);
			}
			if(location!=null){
				q.setParameter("location",location);
			}
			if(name!=null){
				q.setParameter("name", name);
			}
			
			mBlnqr = (BLNQR) q.getSingleResult();
			
			if(mBlnqr != null) {
				Hibernate.initialize(mBlnqr.getBlnqList());
				  List<String> ids=new ArrayList<String>();
				  for(BLNQ blnq:mBlnqr.getBlnqList()){
				  	  ids.add(blnq.getBlnqID());
				  }
				  mBlnqr.setBlnqIds(ids);
				  mBlnqr.setBlnqList(null);
			}
			return mBlnqr;
		}catch(NoResultException noResultException){
			noResultException.printStackTrace();
			return null;
		}
		catch(Exception e){
			// TODO Log Error Message 
			e.printStackTrace();
			return null;
		}finally{
			if(entityManager.isOpen())
				entityManager.close();
		}
	}
public BLNQR fetchBlnqr(String id) {
	EntityManager entityManager = HibernateUtil.createEntityManager();
		try{
			BLNQR blnqr = new BLNQR();
			
			blnqr=entityManager.find(BLNQR.class,id);
			
			return blnqr;
		}catch(Exception e){
			// TODO Log Error Message 
			if(entityManager.isOpen())
				entityManager.close();
			e.printStackTrace();
			return null;
		}
		finally{
			if(entityManager.isOpen())
			entityManager.close();
		}
	}

	
	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqrDAOI#updateBlnqr(com.blnqr.entity.BLNQR)
	 */
	@Override
	public String updateBlnqr(BLNQR mBlnqr) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
				  entityManager.getTransaction().begin();
				  entityManager.merge(mBlnqr);
				  entityManager.getTransaction().commit();
				  return mBlnqr.getBlnqrID();
			  
			}catch(Exception e){
				if(entityManager.isOpen()){
					if(entityManager.getTransaction().isActive())
						entityManager.getTransaction().rollback();
					entityManager.close();
				}
				return null;
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}
		 
	
	}
	
	
	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqrDAOI#deleteBlnqr(com.blnqr.entity.BLNQR)
	 */
	@Override
	public String deleteBlnqr(BLNQR blinqr) {
		// TODO Auto-generated method stub
		EntityManager entityManager = null;
		try{
			entityManager =  HibernateUtil.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.remove(blinqr);
			entityManager.getTransaction().commit();
			entityManager.close();
			return "SUCCESS";
		}catch(Exception e){
			if(entityManager.getTransaction().isActive())
				entityManager.getTransaction().rollback();
			e.printStackTrace();
			return "FAILED : "+e.getMessage();
		}
		finally {
			if(entityManager.isOpen())
				entityManager.close();
		}
	}
}
