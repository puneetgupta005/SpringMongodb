package com.blnqr.dao;

import javax.persistence.EntityManager;

import com.blnqr.entity.BLFILE;
import com.blnqr.util.HibernateUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class BlnqFileDAOImpl.
 */
public class BlnqFileDAOImpl implements BlnqFileDAOI{

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqFileDAOI#createBlnqFile(com.blnqr.entity.BLFILE)
	 */
	@Override
	/**
	 * Creates an file in database.
	 * @return String - ID of the newly created file if successful, otherwise error.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public String createBlnqFile(BLFILE file) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			  entityManager.getTransaction().begin();
			  entityManager.persist(file);
			  entityManager.getTransaction().commit();
			  return file.getBlnqFileID();
			  
			}catch(Exception e){
				if(entityManager.getTransaction().isActive())
					entityManager.getTransaction().rollback();
				return e.getMessage();
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}
		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqFileDAOI#fetchBlnqFile(java.lang.String)
	 */
	@Override
	/**
	 * Fetch a file from Database .
	 * @return  BLFile Object with the Id specified, otherwise null.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public BLFILE fetchBlnqFile(String id) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			 return entityManager.find(BLFILE.class,id);
			  
			}catch(Exception e){
				return null;
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}
		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqFileDAOI#updateBlnqFile(com.blnqr.entity.BLFILE)
	 */
	@Override
	/**
	 * Update a file with the Id specified.
	 * @return   Id of the file specified if success, otherwise return error.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public String updateBlnqFile(BLFILE file) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			  entityManager.getTransaction().begin();
			  entityManager.merge(file);
			  entityManager.getTransaction().commit();
			  return file.getBlnqFileID();
			  
			}catch(Exception e){
				if(entityManager.getTransaction().isActive())
					entityManager.getTransaction().rollback();
				return e.getMessage();
			}
			finally{
				if(entityManager.getTransaction().isActive())
					entityManager.getTransaction().rollback();
			}
		
	}

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqFileDAOI#deleteBlnqFile(com.blnqr.entity.BLFILE)
	 */
	@Override
	/**
	 * Delete a file with the Id specified.
	 * @return   success message if success, otherwise return error.
	 * @author Puneet Gupta
	 * @since 22-March-2017
	 *
	 */
	public String deleteBlnqFile(BLFILE file) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			 entityManager.getTransaction().begin();
			 entityManager.remove(entityManager.find(BLFILE.class,file.getBlnqFileID() ));
			 entityManager.getTransaction().commit();
			 return "success";
			  
			}catch(Exception e){
				if(entityManager.getTransaction().isActive())
					entityManager.getTransaction().rollback();
				return "error";
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}

	}

}
