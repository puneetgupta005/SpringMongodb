package com.blnqr.dao;

import com.blnqr.entity.BLNQR;

// TODO: Auto-generated Javadoc
/**
 * The Interface BlnqrDAOI.
 */
public interface BlnqrDAOI {
	
	/**
	 * Creates the blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the string
	 */
	public String createBlnqr(BLNQR blnqr);
	
	/**
	 * Fetch blnqr.
	 *
	 * @param id the id
	 * @param name the name
	 * @param location the location
	 * @return the blnqr
	 */
	public BLNQR fetchBlnqr(String id, String name, String location);
	
	/**
	 * Update blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the string
	 */
	public String updateBlnqr(BLNQR blnqr);
	
	/**
	 * Delete blnqr.
	 *
	 * @param blnqr the blnqr
	 * @return the string
	 */
	public String deleteBlnqr(BLNQR blnqr);
}
