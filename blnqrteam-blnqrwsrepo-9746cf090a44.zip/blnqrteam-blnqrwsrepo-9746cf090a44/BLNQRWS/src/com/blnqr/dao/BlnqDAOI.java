package com.blnqr.dao;

import java.util.Set;

import com.blnqr.entity.BLNQ;

// TODO: Auto-generated Javadoc
/**
 * The Interface BlnqDAOI.
 */
public interface BlnqDAOI {
	
	/**
	 * Creates the blnq.
	 *
	 * @param blnq the blnq
	 * @return the string
	 */
	public String createBlnq(BLNQ blnq);

	/**
	 * Fetch blnqs.
	 *
	 * @param BlnqrId the blnqr id
	 * @return the sets the
	 */
	public Set<BLNQ> fetchBlnqs(String BlnqrId);
	
	/**
	 * Update blnq.
	 *
	 * @param blnq the blnq
	 * @return the string
	 */
	public String updateBlnq(BLNQ blnq);
	
	/**
	 * Delete blnq.
	 *
	 * @param blnq the blnq
	 * @return the string
	 */
	public String deleteBlnq(BLNQ blnq);
	
	/**
	 * Fetch blnq.
	 *
	 * @param id the id
	 * @return the blnq
	 */
	public BLNQ fetchBlnq(String id);
	
}
