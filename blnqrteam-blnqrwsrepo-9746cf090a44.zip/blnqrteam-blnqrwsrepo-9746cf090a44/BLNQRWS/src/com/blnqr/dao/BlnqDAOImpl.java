package com.blnqr.dao;

import java.util.Set;
import javax.persistence.EntityManager;
import org.hibernate.Hibernate;
import com.blnqr.entity.BLNQ;
import com.blnqr.entity.BLNQR;
import com.blnqr.util.HibernateUtil;

// TODO: Auto-generated Javadoc
/**
 * The Class BlnqDAOImpl.
 */
public class BlnqDAOImpl implements BlnqDAOI {

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqDAOI#createBlnq(com.blnqr.entity.BLNQ)
	 */
	@Override
	/**
	 * Create a Blnq.
	 *
	 * @return  newly created Blnq object ID if success, otherwise return error.
	 * @author Puneet Gupta
	 * @since 23-March-2017
	 *
	 */
	public String createBlnq(BLNQ blnq) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			  entityManager.getTransaction().begin();
			  blnq = entityManager.merge(blnq);
			  entityManager.flush();
			  entityManager.getTransaction().commit();
			  return blnq.getBlnqID();
			  
			}catch(Exception e){
				if(entityManager.getTransaction().isActive())
				entityManager.getTransaction().rollback();
				return null;
			}
			finally{
				if(entityManager.isOpen())
				entityManager.close();
			}
	}

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqDAOI#fetchBlnqs(java.lang.String)
	 */
	@Override
	public Set<BLNQ> fetchBlnqs(String BlnqrId) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			 BLNQR  blnqr=entityManager.find(BLNQR.class,BlnqrId);
			 Hibernate.initialize(blnqr.getBlnqList());
			 return blnqr.getBlnqList();
			  
			}catch(Exception e){
				return null;
			}
			finally{
				if(entityManager.isOpen())
				entityManager.close();
			}

	}
	
	/**
	 * Updates an existing BLNQ in the database.
	 *
	 * @author Amardeep Kumar
	 * @param blnq the blnq
	 * @return String - ID of the updated BLNQ if successful, otherwise null;
	 * @see com.blnqr.dao.BlnqDAOI#updateBlnq(com.blnqr.entity.BLNQ)
	 * @since 21-march-2017
	 */
	@Override
	public String updateBlnq(BLNQ blnq) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
				  entityManager.getTransaction().begin();
				  entityManager.merge(blnq);
				  entityManager.getTransaction().commit();
				  return blnq.getBlnqID();
			  
			}catch(Exception e){
				if(entityManager.isOpen()){
					if(entityManager.getTransaction().isActive())
						entityManager.getTransaction().rollback();
					entityManager.close();
				}
				return null;
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}
	}

	/* (non-Javadoc)
	 * @see com.blnqr.dao.BlnqDAOI#deleteBlnq(com.blnqr.entity.BLNQ)
	 */
	@Override
	public String deleteBlnq(BLNQ blinq) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			  entityManager.getTransaction().begin();
			  entityManager.remove(entityManager.find(BLNQ.class, blinq.getBlnqID()));
			  entityManager.getTransaction().commit();
			  return "Success";
			  
			}catch(Exception e){
				if(entityManager.isOpen()){
					if(entityManager.getTransaction().isActive());
						entityManager.getTransaction().rollback();
					entityManager.close();
				}
				return null;
			}
			finally{
				if(entityManager.isOpen())
					entityManager.close();
			}
	}

	
	
	 
	/**
	 * Fetching existing BLNQ in the database.
	 *
	 * @author Sunny jani
	 * @param id the id
	 * @return String - ID of the updated BLNQ if successful, otherwise null;
	 * @see com.blnqr.dao.BlnqDAOI#fetchBlnq(java.lang.String)
	 * @since 23-march-2017
	 */
	@Override
	public BLNQ fetchBlnq(String id) {
		EntityManager entityManager = HibernateUtil.createEntityManager();
		 try{
			 BLNQ blnq=entityManager.find(BLNQ.class,id);
			 BLNQR blnqrTemp = new BLNQR();
			 Hibernate.initialize(blnq.getBlnqOption1ImgId());
			 blnqrTemp.setBlnqrID(blnq.getBlnqr().getBlnqrID());
			 blnq.setBlnqr(blnqrTemp);
			 blnq.setOption1ImgId(blnq.getBlnqOption1ImgId().getBlnqFileID());
			 blnq.setOption2ImgId(blnq.getBlnqOption2ImgID().getBlnqFileID());
			 blnq.setBlnqOption2ImgID(null);
			 blnq.setBlnqOption1ImgId(null);
			 return blnq;
			}catch(Exception e){
				return null;
		}
		finally{
				if(entityManager.isOpen())
				entityManager.close();
		}
	}

}
