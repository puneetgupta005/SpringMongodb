package com.blnqr.dao;

import com.blnqr.entity.BLFILE;

// TODO: Auto-generated Javadoc
/**
 * The Interface BlnqFileDAOI.
 */
public interface BlnqFileDAOI {
	
	/**
	 * Creates the blnq file.
	 *
	 * @param file the file
	 * @return the string
	 */
	public String createBlnqFile(BLFILE file);
	
	/**
	 * Fetch blnq file.
	 *
	 * @param id the id
	 * @return the blfile
	 */
	public BLFILE fetchBlnqFile(String id);
	
	/**
	 * Update blnq file.
	 *
	 * @param file the file
	 * @return the string
	 */
	public String updateBlnqFile(BLFILE file);
	
	/**
	 * Delete blnq file.
	 *
	 * @param file the file
	 * @return the string
	 */
	public String deleteBlnqFile(BLFILE file);
	
}
