package com.blnqr.entity;

import javax.persistence.Embeddable;

@Embeddable
public class BLNQRFeedBack {
	private boolean displayFlag;
	private String feedText;
	private String feedType;
	public boolean isDisplayFlag() {
		return displayFlag;
	}
	public void setDisplayFlag(boolean displayFlag) {
		this.displayFlag = displayFlag;
	}
	public String getFeedText() {
		return feedText;
	}
	public void setFeedText(String feedText) {
		this.feedText = feedText;
	}
	public String getFeedType() {
		return feedType;
	}
	public void setFeedType(String feedType) {
		this.feedType = feedType;
	}
	
	
	

}
