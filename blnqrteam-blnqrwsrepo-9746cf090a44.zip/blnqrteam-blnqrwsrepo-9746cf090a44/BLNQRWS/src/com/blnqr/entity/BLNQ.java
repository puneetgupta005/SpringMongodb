package com.blnqr.entity;

import java.sql.Time;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class BLNQ.
 */
/**
 * @author supai
 *
 */
/**
 * @author supai
 *
 */
@Entity
public class BLNQ {
	
	/** The blnq ID. */
	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")

	private String blnqID;
	
	/** The blnqr. */
	@ManyToOne
	private BLNQR blnqr;
	
	/** The blnq question. */
	//private String blnqr_blnqrID;
	private String blnqQuestion;
	
	/** The blnq option 1. */
	private String blnqOption1;
	
	/** The blnq option 2. */
	private String blnqOption2;	
	
	/** The blnq option 1 img id. */
	@OneToOne(cascade = CascadeType.PERSIST,fetch=FetchType.LAZY)
	private BLFILE blnqOption1ImgId;
	
	/** The blnq option 2 img ID. */
	@OneToOne(cascade = CascadeType.PERSIST,fetch=FetchType.LAZY)
	private BLFILE blnqOption2ImgID;
	
	/** The blnqcreate by. */
	private String blnqcreateBy;
	
	/** The blnq created date. */
	private Date blnqCreatedDate;
	
	/** The blnq last modified date. */
	private Date blnqLastModifiedDate;
	
	/** The blnq last modified by. */
	private String blnqLastModifiedBy;
	
	/** The blnq context type. */
	private String blnqContextType;
	
	/** The blnq context url. */
	private String blnqContextUrl;
	
	/** The blnq context text. */
	private String blnqContextText;
	
	/** The blnq time out. */
	private int blnqTimeOut;
	
	/** The blnq seq num. */
	private int blnqSeqNum;
	
	/** The option 1 img id. */
	@Transient
	private String option1ImgId;
	
	/** The option 2 img id. */
	@Transient
	private String option2ImgId;
	
	
	/** The blnq version id. */
	private String blnqVersionId;
	
	/** The blnq version number. */
	private String blnqVerisoNum;
	
	/** The feedback. */
	@Embedded
	@OrderColumn(name = "feedback")
	private BLNQFeedBack  feedback;
	
	/** The context image. */
	@OneToOne(cascade = CascadeType.PERSIST,fetch=FetchType.LAZY)
	private BLFILE contextImage;
	
	/** The start time. */
	private Time startTime;
	
	/** The end time. */
	private Time endTime;
	/**
	 * Gets the blnq seq num.
	 *
	 * @return the blnq seq num
	 */
	public int getBlnqSeqNum() {
		return blnqSeqNum;
	}
	
	/**
	 * Sets the blnq seq num.
	 *
	 * @param blnqSeqNum the new blnq seq num
	 */
	public void setBlnqSeqNum(int blnqSeqNum) {
		this.blnqSeqNum = blnqSeqNum;
	}
	
	/**
	 * Gets the blnq ID.
	 *
	 * @return the blnq ID
	 */
	public String getBlnqID() {
		return blnqID;
	}
	
	/**
	 * Sets the blnq ID.
	 *
	 * @param blnqID the new blnq ID
	 * Sets ID of the BLNQ
	 */
	public void setBlnqID(String blnqID) {
		this.blnqID = blnqID;
	}
	
	/**
	 * Gets the blnqr.
	 *
	 * @return the blnqr
	 * Get BLNQR Object to which this BLNQ belong to.
	 */
	public BLNQR getBlnqr() {
		return blnqr;
	}
	
	/**
	 * Sets the blnqr.
	 *
	 * @param blnqr the new blnqr
	 */
	public void setBlnqr(BLNQR blnqr) {
		this.blnqr = blnqr;
	}
/**
 * Gets the blnq question.
 *
 * @return the blnq question
 */
//	}
	
	public String getBlnqQuestion() {
		return blnqQuestion;
	}
	
	/**
	 * Sets the blnq question.
	 *
	 * @param blnqQuestion the new blnq question
	 */
	public void setBlnqQuestion(String blnqQuestion) {
		this.blnqQuestion = blnqQuestion;
	}
	
	/**
	 * Gets the blnq option 1.
	 *
	 * @return the blnq option 1
	 */
	public String getBlnqOption1() {
		return blnqOption1;
	}
	
	/**
	 * Sets the blnq option 1.
	 *
	 * @param blnqOption1 the new blnq option 1
	 */
	public void setBlnqOption1(String blnqOption1) {
		this.blnqOption1 = blnqOption1;
	}
	
	/**
	 * Gets the blnq option 2.
	 *
	 * @return the blnq option 2
	 */
	public String getBlnqOption2() {
		return blnqOption2;
	}
	
	/**
	 * Sets the blnq option 2.
	 *
	 * @param blnqOption2 the new blnq option 2
	 */
	public void setBlnqOption2(String blnqOption2) {
		this.blnqOption2 = blnqOption2;
	}
	
	/**
	 * Gets the blnq option 1 img id.
	 *
	 * @return the blnq option 1 img id
	 */
	public BLFILE getBlnqOption1ImgId() {
		return blnqOption1ImgId;
	}
	
	/**
	 * Sets the blnq option 1 img id.
	 *
	 * @param blnqOption1ImgId the new blnq option 1 img id
	 */
	public void setBlnqOption1ImgId(BLFILE blnqOption1ImgId) {
		this.blnqOption1ImgId = blnqOption1ImgId;
	}
	
	/**
	 * Gets the blnq option 2 img ID.
	 *
	 * @return the blnq option 2 img ID
	 */
	public BLFILE getBlnqOption2ImgID() {
		return blnqOption2ImgID;
	}
	
	/**
	 * Sets the blnq option 2 img ID.
	 *
	 * @param blnqOption2ImgID the new blnq option 2 img ID
	 */
	public void setBlnqOption2ImgID(BLFILE blnqOption2ImgID) {
		this.blnqOption2ImgID = blnqOption2ImgID;
	}
	
	/**
	 * Gets the blnqcreate by.
	 *
	 * @return the blnqcreate by
	 */
	public String getBlnqcreateBy() {
		return blnqcreateBy;
	}
	
	/**
	 * Sets the blnqcreate by.
	 *
	 * @param blnqcreateBy the new blnqcreate by
	 */
	public void setBlnqcreateBy(String blnqcreateBy) {
		this.blnqcreateBy = blnqcreateBy;
	}
	
	/**
	 * Gets the blnq created date.
	 *
	 * @return the blnq created date
	 */
	public Date getBlnqCreatedDate() {
		return blnqCreatedDate;
	}
	
	/**
	 * Sets the blnq created date.
	 *
	 * @param blnqCreatedDate the new blnq created date
	 */
	public void setBlnqCreatedDate(Date blnqCreatedDate) {
		this.blnqCreatedDate = blnqCreatedDate;
	}
	
	/**
	 * Gets the blnq last modified date.
	 *
	 * @return the blnq last modified date
	 */
	public Date getBlnqLastModifiedDate() {
		return blnqLastModifiedDate;
	}
	
	/**
	 * Sets the blnq last modified date.
	 *
	 * @param blnqLastModifiedDate the new blnq last modified date
	 */
	public void setBlnqLastModifiedDate(Date blnqLastModifiedDate) {
		this.blnqLastModifiedDate = blnqLastModifiedDate;
	}
	
	/**
	 * Gets the blnq last modified by.
	 *
	 * @return the blnq last modified by
	 */
	public String getBlnqLastModifiedBy() {
		return blnqLastModifiedBy;
	}
	
	/**
	 * Sets the blnq last modified by.
	 *
	 * @param blnqLastModifiedBy the new blnq last modified by
	 */
	public void setBlnqLastModifiedBy(String blnqLastModifiedBy) {
		this.blnqLastModifiedBy = blnqLastModifiedBy;
	}
	
	/**
	 * Gets the blnq context type.
	 *
	 * @return the blnq context type
	 */
	public String getBlnqContextType() {
		return blnqContextType;
	}
	
	/**
	 * Sets the blnq context type.
	 *
	 * @param blnqContextType the new blnq context type
	 */
	public void setBlnqContextType(String blnqContextType) {
		this.blnqContextType = blnqContextType;
	}
	
	/**
	 * Gets the blnq context url.
	 *
	 * @return the blnq context url
	 */
	public String getBlnqContextUrl() {
		return blnqContextUrl;
	}
	
	/**
	 * Sets the blnq context url.
	 *
	 * @param blnqContextUrl the new blnq context url
	 */
	public void setBlnqContextUrl(String blnqContextUrl) {
		this.blnqContextUrl = blnqContextUrl;
	}
	
	/**
	 * Gets the blnq context text.
	 *
	 * @return the blnq context text
	 */
	public String getBlnqContextText() {
		return blnqContextText;
	}
	
	/**
	 * Sets the blnq context text.
	 *
	 * @param blnqContextText the new blnq context text
	 */
	public void setBlnqContextText(String blnqContextText) {
		this.blnqContextText = blnqContextText;
	}
	
	/**
	 * Gets the blnq time out.
	 *
	 * @return the blnq time out
	 */
	public int getBlnqTimeOut() {
		return blnqTimeOut;
	}
	
	/**
	 * Sets the blnq time out.
	 *
	 * @param blnqTimeOut the new blnq time out
	 */
	public void setBlnqTimeOut(int blnqTimeOut) {
		this.blnqTimeOut = blnqTimeOut;
	}
	
	/**
	 * Gets the option 2 img id.
	 *
	 * @return the option 2 img id
	 */
	public String getOption2ImgId() {
		return option2ImgId;
	}
	
	/**
	 * Sets the option 2 img id.
	 *
	 * @param option2ImgId the new option 2 img id
	 */
	public void setOption2ImgId(String option2ImgId) {
		this.option2ImgId = option2ImgId;
	}

	
	
	/**
	 * Gets the option 1 img id.
	 *
	 * @return the option 1 img id
	 */
	public String getOption1ImgId() {
		return option1ImgId;
	}
	
	/**
	 * Sets the option 1 img id.
	 *
	 * @param option1ImgId the new option 1 img id
	 */
	public void setOption1ImgId(String option1ImgId) {
		this.option1ImgId = option1ImgId;
	}

	/**
	 * Get the blnq version Id.
	 *
	 * @return blnqVersionId
	 */
	public String getBlnqVersionId() {
		return blnqVersionId;
	}

	/**
	 * Sets the blnq version Id.
	 *
	 * @param blnqVersionId the new blnq version id
	 */
	public void setBlnqVersionId(String blnqVersionId) {
		this.blnqVersionId = blnqVersionId;
	}
	
	/**
	 * Get the blnq version number.
	 *
	 * @return blnqVersionId
	 */
	public String getBlnqVerisoNum() {
		return blnqVerisoNum;
	}

	/**
	 * Sets the blnq version number.
	 *
	 * @param blnqVerisoNum the new blnq veriso num
	 */
	public void setBlnqVerisoNum(String blnqVerisoNum) {
		this.blnqVerisoNum = blnqVerisoNum;
	}

	/**
	 * Gets the feedback.
	 *
	 * @return the feedback
	 */
	public BLNQFeedBack getFeedback() {
		return feedback;
	}

	/**
	 * Sets the feedback.
	 *
	 * @param feedback the new feedback
	 */
	public void setFeedback(BLNQFeedBack feedback) {
		this.feedback = feedback;
	}

	/**
	 * Gets the context image.
	 *
	 * @return the context image
	 */
	public BLFILE getContextImage() {
		return contextImage;
	}

	/**
	 * Sets the context image.
	 *
	 * @param contextImage the new context image
	 */
	public void setContextImage(BLFILE contextImage) {
		this.contextImage = contextImage;
	}

	public Time getStartTime() {
		return startTime;
	}

	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}

	public Time getEndTime() {
		return endTime;
	}

	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}
	
	
}
