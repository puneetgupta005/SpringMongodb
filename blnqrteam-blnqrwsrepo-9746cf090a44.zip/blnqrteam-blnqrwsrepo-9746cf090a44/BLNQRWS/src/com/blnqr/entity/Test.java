package com.blnqr.entity;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.hibernate.engine.query.spi.sql.NativeSQLQueryReturn;
import org.hibernate.ogm.OgmSession;
import org.hibernate.ogm.query.NoSQLQuery;

import com.blnqr.dao.BlnqFileDAOImpl;
import com.blnqr.util.HibernateUtil;

public class Test {

	@SuppressWarnings("serial")
	public static void main(String[] args) throws IOException {
		 		
		        EntityManager entityManager = HibernateUtil.createEntityManager();
		       /* entityManager.getTransaction().begin();
		        BLNQR blnqr=new BLNQR();
		        blnqr.setBlnqrCreateDate(new Date());
		        blnqr.setBlnqrLastModifiedDate(new Date());
		        blnqr.setBlnqrName("Demo");
		        BLNQ blnq=new BLNQ();
		        blnq.setBlnqContextType("image");
		        blnq.setBlnqContextUrl("");
		        blnq.setBlnqContextText("image");
		        blnq.setBlnqLastModifiedBy("Admin");
		        blnq.setBlnqLastModifiedDate(new Date());
		        blnq.setBlnqCreatedDate(new Date());
		        blnq.setBlnqOption1("1");
		        blnq.setBlnqOption2("2");
		        BLFILE file=new BLFILE();
		        Path path = Paths.get("/home/supai/Downloads/images.jpg");
		        file.setFileCreateDate(new Date());
		        file.setFileData(Files.readAllBytes(path));
		        file.setFileMimeType("image/jpg");
		        file.setFileType("jpg");
		        blnq.setBlnqOption1ImgId(file);
		        blnq.setBlnqOption2ImgID(file);
		        blnqr.setBlnqList(new HashSet<BLNQ>(){{add(blnq);}});
		        blnq.setBlnqr(blnqr);
		        entityManager.persist(blnqr);
		        entityManager.getTransaction().commit();
		        entityManager.close();
		        entityManager = HibernateUtil.createEntityManager();*/
		        //join operation although criteria query are not supported in hibernate ogm
		       /* CriteriaBuilder builder=entityManager.getCriteriaBuilder();
		        CriteriaQuery query=builder.createQuery();
		        Root blnq= query.from(BLNQ.class);
		        Join file1 = ((From) blnq).join("blnqOption1ImgId");
		        Join file2= ((From) blnq).join("blnqOption2ImgID");
		        query.where(builder.and(builder.equal(file1.get("blnqFileID"),"24bbb5f6-f14c-4994-a497-9fa3b7fd3d68"),builder.equal(file2.get("blnqFileID"),"24bbb5f6-f14c-4994-a497-9fa3b7fd3d68") ));
		        Query q = entityManager.createQuery(query);
		        List<BLNQ>blnqs=q.getResultList();*/
		        
		        String query="{ $and: [ { _id : 'b55639df-73ed-406f-ae91-7739cf4bcc27' }, { blnqcreateBy : 'Admin' } ] }";
		        Query q=entityManager.createNativeQuery(query,BLNQ.class);
		        List<BLNQ> l=q.getResultList();
		        for(BLNQ blnq :l){
		        	System.out.println(blnq.getBlnqcreateBy());
		        }
		        
		        
		       System.out.println("time");
		    }
		

	

}
