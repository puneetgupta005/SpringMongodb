package com.blnqr.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class BLFILE.
 */
@Entity
public class BLFILE {
	
	/** The blnq file ID. */
	
	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
	private String blnqFileID;
	
	/** The file name. */
	private String fileName;
	
	/** The file type. */
	private String fileType;
	
	/** The file mime type. */
	private String fileMimeType;
	
	/** The file size. */
	private double fileSize;
	
	/** The file create date. */
	private Date fileCreateDate;
	
	/** The file data. */
	private byte[] fileData;
	
	/**
	 * Gets the blnq file ID.
	 *
	 * @return the blnq file ID
	 */
	public String getBlnqFileID() {
		return blnqFileID;
	}
	
	/**
	 * Sets the blnq file ID.
	 *
	 * @param blnqFileID the new blnq file ID
	 */
	public void setBlnqFileID(String blnqFileID) {
		this.blnqFileID = blnqFileID;
	}
	
	/**
	 * Gets the file name.
	 *
	 * @return the file name
	 */
	public String getFileName() {
		return fileName;
	}
	
	/**
	 * Sets the file name.
	 *
	 * @param fileName the new file name
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * Gets the file type.
	 *
	 * @return the file type
	 */
	public String getFileType() {
		return fileType;
	}
	
	/**
	 * Sets the file type.
	 *
	 * @param fileType the new file type
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
	/**
	 * Gets the file mime type.
	 *
	 * @return the file mime type
	 */
	public String getFileMimeType() {
		return fileMimeType;
	}
	
	/**
	 * Sets the file mime type.
	 *
	 * @param fileMimeType the new file mime type
	 */
	public void setFileMimeType(String fileMimeType) {
		this.fileMimeType = fileMimeType;
	}
	
	/**
	 * Gets the file size.
	 *
	 * @return the file size
	 */
	public double getFileSize() {
		return fileSize;
	}
	
	/**
	 * Sets the file size.
	 *
	 * @param fileSize the new file size
	 */
	public void setFileSize(double fileSize) {
		this.fileSize = fileSize;
	}
	
	/**
	 * Gets the file create date.
	 *
	 * @return the file create date
	 */
	public Date getFileCreateDate() {
		return fileCreateDate;
	}
	
	/**
	 * Sets the file create date.
	 *
	 * @param fileCreateDate the new file create date
	 */
	public void setFileCreateDate(Date fileCreateDate) {
		this.fileCreateDate = fileCreateDate;
	}
	
	/**
	 * Gets the file data.
	 *
	 * @return the file data
	 */
	public byte[] getFileData() {
		return fileData;
	}
	
	/**
	 * Sets the file data.
	 *
	 * @param fileData the new file data
	 */
	public void setFileData(byte[] fileData) {
		this.fileData = fileData;
	}
	
	

}
