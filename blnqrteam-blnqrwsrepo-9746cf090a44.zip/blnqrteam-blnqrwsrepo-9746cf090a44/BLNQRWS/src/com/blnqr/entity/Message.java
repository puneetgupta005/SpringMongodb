package com.blnqr.entity;

import javax.persistence.Embeddable;

@Embeddable
public class Message {
	private boolean displayFlag;
	private String msgHeader;
	private String msgText;
	private String btnOKText;
	private String btnCancelText;
	public boolean isDisplayFlag() {
		return displayFlag;
	}
	public void setDisplayFlag(boolean displayFlag) {
		this.displayFlag = displayFlag;
	}
	public String getMsgHeader() {
		return msgHeader;
	}
	public void setMsgHeader(String msgHeader) {
		this.msgHeader = msgHeader;
	}
	public String getMsgText() {
		return msgText;
	}
	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}
	public String getBtnOKText() {
		return btnOKText;
	}
	public void setBtnOKText(String btnOKText) {
		this.btnOKText = btnOKText;
	}
	public String getBtnCancelText() {
		return btnCancelText;
	}
	public void setBtnCancelText(String btnCancelText) {
		this.btnCancelText = btnCancelText;
	}
	
	

}
