package com.blnqr.entity;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

// TODO: Auto-generated Javadoc
/**
 * BLNQR Entity class
 * @author supai infotech
 * @since 20-March-2017
 * @version 1.0
 * @see BLNQ
 */
@Entity
public class BLNQR {
	
	/** The blnqr ID. */
	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
	private String blnqrID;
	
	/** The blnqr name. */
	private String blnqrName;
	
	/** The blnqr icon. */
	private String blnqrIcon;
	
	/** The blnqr location. */
	private String blnqrLocation;
	
	/** The blnqr created by. */
	private String blnqrCreatedBy;
	
	/** The blnqr create date. */
	private Date blnqrCreateDate;
	
	/** The blnqr last modified date. */
	private Date blnqrLastModifiedDate;
	
	/** The blnqr last modified by. */
	private String blnqrLastModifiedBy;
	
	/** The blnq list. */
	@OneToMany(mappedBy = "blnqr", cascade = CascadeType.PERSIST)
	private Set<BLNQ> blnqList;
	
	/** The blnqr status. */
	private String blnqrStatus;
	
	/** The blnqrsearch terms. */
	@ElementCollection
	private List<String> blnqrsearchTerms;
	
	/** The blnq ids. */
	@Transient
	List<String>blnqIds;
	
	/**
	 * The blnqr version id
	 */
	private String blnqrVersionId;
	
	/**
	 * The blnqr version number
	 */
	private String blnqrVersionNum;
	
	@Embedded
	@OrderColumn(name = "message")
	private Message message;
	
	@Embedded
	@OrderColumn(name = "feedback")
	private BLNQRFeedBack feedback;
	
	/**
	 * Gets the blnq ids.
	 *
	 * @return the blnq ids
	 */
	
	public List<String> getBlnqIds() {
		return blnqIds;
	}
	
	/**
	 * Sets the blnq ids.
	 *
	 * @param blnqIds the new blnq ids
	 */
	public void setBlnqIds(List<String> blnqIds) {
		this.blnqIds = blnqIds;
	}
	
	/**
	 * Gets the blnqr ID.
	 *
	 * @return the blnqr ID
	/**
	 * Get Id of the BLNQR
	 * @return blnqrID
	 */
	public String getBlnqrID() {
		return blnqrID;
	}
	
	/**
	 * Sets the blnqr ID.
	 *
	 * @param blnqrID the new blnqr ID
	 * Set Id of the BLNQR
	 * @param blnqrID
	 */
	public void setBlnqrID(String blnqrID) {
		this.blnqrID = blnqrID;
	}
	
	/**
	 * Gets the blnqr name.
	 *
	 * @return the blnqr name
	 * Get BLNQR Name
	 * @return blnqrName
	 */
	public String getBlnqrName() {
		return blnqrName;
	}
	
	/**
	 * Sets the blnqr name.
	 *
	 * @param blnqrName the new blnqr name
	 * Set BLNQR Name
	 * @param blnqrName
	 */
	public void setBlnqrName(String blnqrName) {
		this.blnqrName = blnqrName;
	}
	
	/**
	 * Gets the blnqr icon.
	 *
	 * @return the blnqr icon
	 * Get BLNQR icon
	 * @return blnqrIcon;
	 */
	public String getBlnqrIcon() {
		return blnqrIcon;
	}
	
	/**
	 * Sets the blnqr icon.
	 *
	 * @param blnqrIcon the new blnqr icon
	 * Set BLNQR icon
	 * @param blnqrIcon
	 */
	public void setBlnqrIcon(String blnqrIcon) {
		this.blnqrIcon = blnqrIcon;
	}
	
	/**
	 *
	 * Get BLNQR location
	 * @return blnqrLocation
	 */
	public String getBlnqrLocation() {
		return blnqrLocation;
	}
	
	/**
	 * Set BLNQR location
	 * @param blnqrLocation
	 */
	public void setBlnqrLocation(String blnqrLocation) {
		this.blnqrLocation = blnqrLocation;
	}
	
	/**
	 * Gets the blnqr created by.
	 *
	 * @return blnqrCreatedBy
	 */
	public String getBlnqrCreatedBy() {
		return blnqrCreatedBy;
	}
	
	/**
	 * Set user who created this BLNQR
	 * @param blnqrCreatedBy
	 */
	public void setBlnqrCreatedBy(String blnqrCreatedBy) {
		this.blnqrCreatedBy = blnqrCreatedBy;
	}
	
	/**
	 * Gets the blnqr create date.
	 *
	 * @return the blnqr create date
	 */
	public Date getBlnqrCreateDate() {
		return blnqrCreateDate;
	}
	
	/**
	 *
	 * Set BLNQR create date
	 * @param blnqrCreateDate
	 */
	public void setBlnqrCreateDate(Date blnqrCreateDate) {
		this.blnqrCreateDate = blnqrCreateDate;
	}
	
	/**
	 * Get BLNQR Modified date
	 * @return blnqrLastModifiedDate
	 */
	public Date getBlnqrLastModifiedDate() {
		return blnqrLastModifiedDate;
	}
	
	/**
	 * Set BLNQR last modified date
	 * @param blnqrLastModifiedDate
	 */
	public void setBlnqrLastModifiedDate(Date blnqrLastModifiedDate) {
		this.blnqrLastModifiedDate = blnqrLastModifiedDate;
	}
	
	/**
	 * Get user who modified this BLNQR
	 * @return blnqrLastModifiedBy
	 */
	public String getBlnqrLastModifiedBy() {
		return blnqrLastModifiedBy;
	}
	
	/**
	 * Set user who last modified this BLNQR
	 * @param blnqrLastModifiedBy
	 */
	public void setBlnqrLastModifiedBy(String blnqrLastModifiedBy) {
		this.blnqrLastModifiedBy = blnqrLastModifiedBy;
	}
	
	/**
	 * Get List of all the BLNQs which belongs to this BLNQR
	 * @return
	 */
	public Set<BLNQ> getBlnqList() {
		return blnqList;
	}
	
	/**
	 * Set BLNQ list
	 * @param blnqList
	 */
	public void setBlnqList(Set<BLNQ> blnqList) {
		this.blnqList = blnqList;
	}
	
	/**
	 * Gets the blnqr status.
	 *
	 * @return the blnqr status
	 * Get BLNQR status
	 * @return blnqrStatus
	 */
	public String getBlnqrStatus() {
		return blnqrStatus;
	}
	
	/**
	 * Sets the blnqr status.
	 *
	 * @param blnqrStatus the new blnqr status
	 */
	public void setBlnqrStatus(String blnqrStatus) {
		this.blnqrStatus = blnqrStatus;
	}
	
	/**
	 * Gets the blnqrsearch terms.
	 *
	 * @return the blnqrsearch terms
	 */
	public List<String> getBlnqrsearchTerms() {
		return blnqrsearchTerms;
	}
	
	/**
	 * Set BLNQR search terms
	 * @param blnqrsearchTerms
	 */
	public void setBlnqrsearchTerms(List<String> blnqrsearchTerms) {
		this.blnqrsearchTerms = blnqrsearchTerms;
	}

	/**
	 * Get blnqr version id
	 * @return blnqrVersionId
	 */
	public String getBlnqrVersionId() {
		return blnqrVersionId;
	}

	/**
	 * Sets blnqr version id
	 * @param blnqrVersionId
	 */
	public void setBlnqrVersionId(String blnqrVersionId) {
		this.blnqrVersionId = blnqrVersionId;
	}

	/**
	 * Get the blnqr version number
	 * @return blnqrVersionNum
	 */
	public String getBlnqrVersionNum() {
		return blnqrVersionNum;
	}

	/**
	 * Sets blnqr version number
	 * @param blnqrVersionNum
	 */
	public void setBlnqrVersionNum(String blnqrVersionNum) {
		this.blnqrVersionNum = blnqrVersionNum;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public BLNQRFeedBack getFeedback() {
		return feedback;
	}

	public void setFeedback(BLNQRFeedBack feedback) {
		this.feedback = feedback;
	}
	
	

}
