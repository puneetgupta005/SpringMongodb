package com.web.blnqr.controller;
import java.io.IOException;
import java.util.Base64;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.web.blnqr.dao.BlnqrDao;
import com.web.blnqr.model.Blnqr;
import com.web.blnqr.model.BlnqrMessage;

@Controller
public class BlnqrController {
	
	
	@RequestMapping("/createBlnqrForm")
	public ModelAndView showCreateBlnqr(){
		return new ModelAndView("createBlnqr","command",new Blnqr());
	}
	
	@RequestMapping(value="/doCreateBlnqr", method=RequestMethod.POST)
	public ModelAndView createBlnqr(@ModelAttribute("blnqr") Blnqr blnqr){
		
		BlnqrDao blnqrDao = new BlnqrDao();
		BlnqrMessage blnqrMessage = blnqrDao.createBlnqr(blnqr);
	    
		if(blnqrMessage!=null && blnqrMessage.getID()!=null && !blnqrMessage.getID().trim().equals("")){
			System.out.println("blnqr created :"+blnqrMessage.getID()+"  "+blnqrMessage.getMessage());
			return new ModelAndView("blnqrCreationSuccess");
		}else{
			//TO DO : Write code for deleting the created file in case blnqr creation failed
			return new ModelAndView("blnqrCreationFailed");
		}
	}
	
	
	@RequestMapping("/showBlnqr")
	public ModelAndView getBlnqr( @RequestParam(value="name",required=false) String name, @RequestParam(value="id",required=false)String id, @RequestParam(value="location",required=false)String location, HttpServletResponse response,HttpServletRequest request){
		BlnqrDao blnqrDao = new BlnqrDao();
		
		Blnqr blnqr = blnqrDao.getBlnqr(id, name, location);
		if(blnqr==null){
			return new ModelAndView("blnqrCreationFailed");
		}
		//response.setContentType("mulipart/form-data");
		byte[] encodeBase64;
		String base64Encoded=null;
		try {
			if(blnqr.getBlnqrIcon() != null){
				encodeBase64 = Base64.getEncoder().encode(blnqr.getBlnqrIcon().getBytes());
				base64Encoded = new String(encodeBase64, "UTF-8");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
		if(blnqr != null){
			ModelAndView modelview=new ModelAndView("viewBlnqr","command",blnqr);
			modelview.addObject("image",base64Encoded );
			return modelview;
		}
		else{
			return new ModelAndView("blnqrCreationFailed");
		}
	}
	
	@RequestMapping(value="/editBlnqr",method=RequestMethod.POST)
	public ModelAndView editBlnqr(@ModelAttribute("Blnqr") Blnqr blnqr){
		//response.setContentType("mulipart/form-data");
		BlnqrDao blnqrDao = new BlnqrDao();
		
		Blnqr editblnqr = blnqrDao.getBlnqr(blnqr.getBlnqrID(), null,null );

		byte[] encodeBase64;
		String base64Encoded=null;
		try {
			if(editblnqr.getBlnqrIcon() != null){
				encodeBase64 = Base64.getEncoder().encode(editblnqr.getBlnqrIcon().getBytes());
				base64Encoded = new String(encodeBase64, "UTF-8");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
		if(blnqr != null){
			ModelAndView modelview=new ModelAndView("updateBlnqr","command",editblnqr);
			modelview.addObject("image",base64Encoded );
			return modelview;
		}
		else{
			return new ModelAndView("blnqrCreationFailed");
		}
		
	}
	@RequestMapping(value="/doUpdateBlnqr", method=RequestMethod.POST)
	public ModelAndView updateBlnqr(@ModelAttribute("blnqr") Blnqr blnqr){
		
		BlnqrDao blnqrDao = new BlnqrDao();
		BlnqrMessage blnqrMessage = blnqrDao.updateBlnqr(blnqr);
	    
		if(blnqrMessage!=null && blnqrMessage.getID()!=null && !blnqrMessage.getID().trim().equals("")){
			System.out.println("blnqr updated :"+blnqrMessage.getID()+"  "+blnqrMessage.getMessage());
			return new ModelAndView("blnqrCreationSuccess");
		}else{
			//TO DO : Write code for deleting the created file in case blnqr creation failed
			return new ModelAndView("blnqrCreationFailed");
		}
	}
	
	@RequestMapping(value="/createFile", method=RequestMethod.POST)
	@ResponseBody
	public BlnqrMessage createFile(@RequestBody MultipartFile file){
		BlnqrMessage message = new BlnqrMessage();
		BlnqrDao blnqrDao = new BlnqrDao();
		message = blnqrDao.createFile(file);
		if(message != null && message.getID()!=null && !message.getID().trim().equals("")){
			System.out.println("Icon Created :"+message.getID()+"  "+message.getMessage());
			return message;
		}
		return null;
	}
	
	@RequestMapping(value="/updateFile", method=RequestMethod.POST)
	@ResponseBody
	public BlnqrMessage updateFile(@RequestParam MultipartFile file, @RequestParam String id){
		BlnqrMessage message = new BlnqrMessage();
		BlnqrDao blnqrDao = new BlnqrDao();
		message = blnqrDao.updateFile(file, id);
		if(message != null && message.getId() != null && !message.getId().trim().equals("")){
			System.out.println("Icon Updated : "+message.getId()+" "+message.getMessage());
			return message;
		}
		return null;
	}
}
