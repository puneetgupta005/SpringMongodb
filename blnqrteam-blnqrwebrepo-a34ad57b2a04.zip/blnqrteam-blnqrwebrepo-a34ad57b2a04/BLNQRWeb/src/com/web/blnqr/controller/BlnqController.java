package com.web.blnqr.controller;


import java.io.IOException;
import java.util.Base64;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.web.blnqr.dao.BlnqDao;
import com.web.blnqr.dao.BlnqrDao;
import com.web.blnqr.model.BLNQ;
import com.web.blnqr.model.Blnqr;
import com.web.blnqr.model.ResponseMessage;

@Controller
public class BlnqController {
	
	@RequestMapping("/createBlnqForm")
	public ModelAndView showCreateBlnq(){
		return new ModelAndView("createBlnq","command", new BLNQ()); 
	}
	
	@RequestMapping(value="/doCreateBlnq", method=RequestMethod.POST)
	public ModelAndView createBlnq(@ModelAttribute("blnq") BLNQ blnq){
		
		if(!doValidateBlnq(blnq)) {
			return new ModelAndView("blnqCreationFailed");
		}
		BlnqDao blnqrDao = new BlnqDao();
		ResponseMessage mResponse = blnqrDao.createBlnq(blnq);
		if(mResponse!=null && mResponse.getID()!=null && !mResponse.getID().trim().equals("")){
			System.out.println("blnq created :"+mResponse.getID()+"  "+mResponse.getMessage());
			return new ModelAndView("blnqCreationSuccess");
		}else{
			//TO DO : Write code for deleting the created file in case blnq creation failed
			return new ModelAndView("blnqCreationFailed");
		}
	}
	
	@RequestMapping(value="/editBlnq", method=RequestMethod.POST)
	public ModelAndView editBlnq(@ModelAttribute("blnq") BLNQ blnq){
		
		if(!doValidateBlnq(blnq)) {
			return new ModelAndView("blnqCreationFailed");
		}
		BlnqDao blnqrDao = new BlnqDao();
		ResponseMessage mResponse = blnqrDao.editBlnq(blnq);
		if(mResponse!=null && mResponse.getID()!=null && !mResponse.getID().trim().equals("")){
			System.out.println("blnq upadated :"+mResponse.getID()+"  "+mResponse.getMessage());
			return new ModelAndView("blnqCreationSuccess");
		}else{
			//TO DO : Write code for deleting the created file in case blnq updation failed
			return new ModelAndView("blnqCreationFailed");
		} 
	}
	
	
	@RequestMapping("/updateBlnq")
	public ModelAndView updateBlnq(  @RequestParam(value="id",required=false)String id){
		BlnqDao mBlnqDao = new BlnqDao(); 
		BLNQ mBlnq = mBlnqDao.getBlnq(id);
		byte[] encodeBase64;
		String base64Encodedopt1=null,base64Encodedopt2=null;
		if(mBlnq != null) {
			try {
				ModelAndView modelview = new ModelAndView("editBlnq","command",mBlnq);
				if(mBlnq.getOption1Img() != null && !mBlnq.getOption1Img().isEmpty()) {
					encodeBase64 = Base64.getEncoder().encode(mBlnq.getOption1Img().getBytes());
					base64Encodedopt1 = new String(encodeBase64, "UTF-8");
					modelview.addObject("option1Img",base64Encodedopt1);
				}
				if(mBlnq.getOption2Img() != null && !mBlnq.getOption2Img().isEmpty()) {
					encodeBase64 = Base64.getEncoder().encode(mBlnq.getOption2Img().getBytes());
					base64Encodedopt2 = new String(encodeBase64, "UTF-8");
					modelview.addObject("option2Img",base64Encodedopt2);
				}
				modelview.addObject("cttype",mBlnq.getBqContType());
				modelview.addObject("fbflag",mBlnq.getBqFeedback().isDisplayFlag()); 
				return modelview;	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());				
				e.printStackTrace();
				return new ModelAndView("blnqrCreationFailed");
			}
		}
		else 
			return new ModelAndView("blnqrCreationFailed");
	}
	
	@RequestMapping("/showBlnq")
	public ModelAndView showBlnq(  @RequestParam(value="id",required=false)String id){
		BlnqDao mBlnqDao = new BlnqDao(); 
		BLNQ mBlnq = mBlnqDao.getBlnq(id);
		byte[] encodeBase64;
		String base64Encodedopt1=null,base64Encodedopt2=null;
		if(mBlnq != null) {
			try {
				ModelAndView modelview = new ModelAndView("showBlnq","command",mBlnq);
				modelview.addObject("b", mBlnq);
				if(mBlnq.getOption1Img() != null && !mBlnq.getOption1Img().isEmpty()) {
					encodeBase64 = Base64.getEncoder().encode(mBlnq.getOption1Img().getBytes());
					base64Encodedopt1 = new String(encodeBase64, "UTF-8");
					modelview.addObject("option1Img",base64Encodedopt1); 
				} 
				if(mBlnq.getOption2Img() != null && !mBlnq.getOption2Img().isEmpty()) {
					encodeBase64 = Base64.getEncoder().encode(mBlnq.getOption2Img().getBytes());
					base64Encodedopt2 = new String(encodeBase64, "UTF-8");
					modelview.addObject("option2Img",base64Encodedopt2);
				}
				//splayFlag()); 
				return modelview;	
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());				
				e.printStackTrace();
				return new ModelAndView("blnqrCreationFailed");
			}
		}
		else 
			return new ModelAndView("blnqrCreationFailed");
	}
	 
	private Boolean doValidateBlnq(BLNQ blnq) {
		// TODO Auto-generated method stub
		if(blnq.getBqOpt1().trim()=="" || blnq.getBqOpt2().trim()=="")
			return false;
		if(blnq.getBqFeedback().isDisplayFlag()) {
			if(blnq.getBqFeedback().getFeedText().trim()=="" || blnq.getBqFeedback().getFeedType().trim()=="") {
				return false; 
			}
		} 
		if(blnq.getBqContType().trim()!="") {
			switch(blnq.getBqContType().toLowerCase().trim()) {
				case "text" :
					if(blnq.getBqQue().trim()=="")
						return false;
					break;
				case "video" :
					if(blnq.getBqContUrl().trim()=="")
						return false;
					break;
				//case "image":
				//	if(blnq.getBq().trim()=="")
				//		return new ModelAndView("blnqCreationFailed");
				//	break;
			}
		}
		return true;
	}
	

	public ModelAndView getBlnq(String id){
		
		return new ModelAndView();
	}
}