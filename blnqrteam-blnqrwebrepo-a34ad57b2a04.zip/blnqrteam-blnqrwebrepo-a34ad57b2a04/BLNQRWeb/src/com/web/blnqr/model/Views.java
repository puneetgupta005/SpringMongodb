package com.web.blnqr.model;


public class Views {
	public static class Public {
	}
}
