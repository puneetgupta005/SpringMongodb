package com.web.blnqr.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "displayFlag", "msgHeader", "msgText", "btnOKText", "btnCancelText" })
public class Message {

	@JsonProperty("displayFlag")
	private boolean displayFlag;
	@JsonProperty("msgHeader")
	private String msgHeader;
	@JsonProperty("msgText")
	private String msgText;
	@JsonProperty("btnOKText")
	private String btnOKText;
	@JsonProperty("btnCancelText")
	private String btnCancelText;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("displayFlag")
	public boolean isDisplayFlag() {
		return displayFlag;
	}

	@JsonProperty("displayFlag")
	public void setDisplayFlag(boolean displayFlag) {
		this.displayFlag = displayFlag;
	}

	@JsonProperty("msgHeader")
	public String getMsgHeader() {
		return msgHeader;
	}

	@JsonProperty("msgHeader")
	public void setMsgHeader(String msgHeader) {
		this.msgHeader = msgHeader;
	}

	@JsonProperty("msgText")
	public String getMsgText() {
		return msgText;
	}

	@JsonProperty("msgText")
	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}

	@JsonProperty("btnOKText")
	public String getBtnOKText() {
		return btnOKText;
	}

	@JsonProperty("btnOKText")
	public void setBtnOKText(String btnOKText) {
		this.btnOKText = btnOKText;
	}

	@JsonProperty("btnCancelText")
	public String getBtnCancelText() {
		return btnCancelText;
	}

	@JsonProperty("btnCancelText")
	public void setBtnCancelText(String btnCancelText) {
		this.btnCancelText = btnCancelText;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}