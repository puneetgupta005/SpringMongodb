package com.web.blnqr.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "displayFlag", "feedText", "feedType" })
public class Feedback {

	@JsonProperty("displayFlag")
	private boolean displayFlag;
	@JsonProperty("feedText")
	private String feedText;
	@JsonProperty("feedType")
	private String feedType;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public Feedback() {};
	
	public Feedback(boolean displayFlag, String feedText, String feedType) {
		super();
		this.displayFlag = displayFlag;
		this.feedText = feedText;
		this.feedType = feedType;
	}

	@JsonProperty("displayFlag")
	public boolean isDisplayFlag() {
		return displayFlag;
	}

	@JsonProperty("displayFlag")
	public void setDisplayFlag(boolean displayFlag) {
		this.displayFlag = displayFlag;
	}

	@JsonProperty("feedText")
	public String getFeedText() {
		return feedText;
	}

	@JsonProperty("feedText")
	public void setFeedText(String feedText) {
		this.feedText = feedText;
	}

	@JsonProperty("feedType")
	public String getFeedType() {
		return feedType;
	}

	@JsonProperty("feedType")
	public void setFeedType(String feedType) {
		this.feedType = feedType;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
