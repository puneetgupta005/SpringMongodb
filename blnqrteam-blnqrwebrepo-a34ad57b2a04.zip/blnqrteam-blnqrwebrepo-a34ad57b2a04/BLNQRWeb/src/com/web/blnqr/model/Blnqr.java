
package com.web.blnqr.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "blnqrName","blnqrIcon","blnqrLocation", "feedback", "message" })
public class Blnqr implements Validator{
	
	@JsonProperty("blnqrName")
	private String blnqrName;
	@JsonProperty("blnqrID")
	private String blnqrID;
	@JsonIgnore
	private boolean updateIcon;
	@JsonIgnore
	private MultipartFile blnqrIcon;
	@JsonProperty("blnqrLocation")
	private String blnqrLocation;
	@JsonProperty("feedback")
	private Feedback feedback;
	@JsonProperty("message")
	private Message message;
	private String searchTerms;
	@JsonProperty("blnqrsearchTerms")
	private List<String> blnqrsearchTerms = null;
	@JsonIgnore 
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	
	@JsonProperty("blnqrIcon")
	private String blnqrIconId;
	@JsonProperty("blnqrName")
	public String getBlnqrName() {
		return blnqrName;
	} 
	public String getSearchTerms() {
		return searchTerms;
	}
	public void setSearchTerms(String searchTerms) {
		this.searchTerms = searchTerms;
	}
	@JsonProperty("blnqrIcon")
	public String getBlnqrIconId() {
		return blnqrIconId;
	}
	@JsonProperty("blnqrIcon")
	public void setBlnqrIconId(String blnqrIconId) {
		this.blnqrIconId = blnqrIconId;
	}

	@JsonProperty("blnqrName")
	public void setBlnqrName(String blnqrName) {
		this.blnqrName = blnqrName;
	}
	@JsonIgnore
	public MultipartFile getBlnqrIcon() {
		return blnqrIcon;
	}
	@JsonIgnore
	public void setBlnqrIcon(MultipartFile blnqrIcon) {
		this.blnqrIcon = blnqrIcon;
	}
	@JsonProperty("feedback")
	public Feedback getFeedback() {
		return feedback;
	}

	@JsonProperty("feedback")
	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}

	@JsonProperty("message")
	public Message getMessage() {
		return message;
	}

	@JsonProperty("message")
	public void setMessage(Message message) {
		this.message = message;
	}
	
	
	@JsonProperty("blnqrLocation")
	public String getBlnqrLocation() {
		return blnqrLocation;
	}
	
	@JsonProperty("blnqrLocation")
	public void setBlnqrLocation(String blnqrLocation) {
		this.blnqrLocation = blnqrLocation;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}
	@JsonProperty("blnqrsearchTerms")
	public List<String> getBlnqrsearchTerms() {
		return blnqrsearchTerms;
	}
	@JsonProperty("blnqrsearchTerms")
	public void setBlnqrsearchTerms(List<String> blnqrsearchTerms) {
		this.blnqrsearchTerms = blnqrsearchTerms;
	}
	public String getBlnqrID() {
		return blnqrID;
	}
	public void setBlnqrID(String blnqrID) {
		this.blnqrID = blnqrID;
	}
	public boolean isUpdateIcon() {
		return updateIcon;
	}
	public void setUpdateIcon(boolean updateIcon) {
		this.updateIcon = updateIcon;
	}
	@Override
	public boolean supports(Class<?> clazz) {
		return Blnqr.class.equals(clazz);
	}
	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmpty(errors, "blnqrName", "blnqrName is required");
		if(blnqrName.equals("a")){
			errors.rejectValue("blnqrName", "InvalidValue");
		}
		
	}
	
	
}
