package com.web.blnqr.model;



import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"blnqID","blnqQuestion","blnqOption1","blnqOption2","blnqOption1ImgId","blnqOption2ImgID",
	"blnqContextType","blnqContextUrl","blnqcreateBy","blnqLastModifiedBy","blnqVersionId","blnqVerisoNum","blnqSeqNum",
	"blnqContextText","blnqTimeOut","feedback","blnqr"})
public class BLNQ {
	@JsonProperty("blnqID")
	private String bqId;
	@JsonProperty("blnqQuestion")
	private String bqQue;
	@JsonProperty("blnqOption1")
	private String bqOpt1;
	@JsonProperty("blnqOption2")
	private String bqOpt2;
	@JsonProperty("blnqOption1ImgId")
	private BLNQImage bqOpt1ImgID;
	@JsonProperty("blnqOption2ImgID")
	private BLNQImage bqOpt2ImgID;
	@JsonProperty("blnqcreateBy")
	private String bqCreatedBy;
	@JsonProperty("blnqLastModifiedBy")
	private String bqLastModBy;
	@JsonProperty("blnqContextType")
	private String bqContType;
	@JsonProperty("blnqContextUrl")
	private String bqContUrl;
	@JsonProperty("blnqContextText")
	private String bqContText;
	@JsonProperty("blnqTimeOut")
	private int bqTimeOut;
	@JsonProperty("blnqSeqNum")
	private int bqSeqNum;
	@JsonProperty("blnqVersionId")
	private String bqVerId;
	@JsonProperty("blnqVerisoNum")
	private String bqVerNum;
	@JsonProperty("blnqr")
	private BlnqBlnqr mBlnqr;
	@JsonProperty("feedback")
	private Feedback  bqFeedback;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	@JsonIgnore
	private MultipartFile option1Img;
	@JsonIgnore
	private MultipartFile option2Img;
	@JsonIgnore
	private Date bqCreatedDate;
	@JsonIgnore
	private boolean opt1Imgchanged;
	@JsonIgnore
	private boolean opt2Imgchanged;
	@JsonIgnore
	private String oldOpt1ImgId;
	@JsonIgnore
	private String oldOpt2ImgId;
	
	@JsonProperty("blnqQuestion")
	public String getBqQue() {
		return bqQue;
	}
	@JsonProperty("blnqQuestion")
	public void setBqQue(String bqQue) {
		this.bqQue = bqQue;
	}
	@JsonProperty("blnqOption1")
	public String getBqOpt1() {
		return bqOpt1;
	}
	@JsonProperty("blnqOption1")
	public void setBqOpt1(String bqOpt1) {
		this.bqOpt1 = bqOpt1;
	}
	@JsonProperty("blnqOption2")
	public String getBqOpt2() {
		return bqOpt2;
	}
	@JsonProperty("blnqOption2")
	public void setBqOpt2(String bqOpt2) {
		this.bqOpt2 = bqOpt2;
	}
	@JsonProperty("blnqOption1ImgId")
	public BLNQImage getBqOpt1ImgID() {
		return bqOpt1ImgID;
	}
	@JsonProperty("blnqOption1ImgId")
	public void setBqOpt1ImgID(BLNQImage bqOpt1ImgID) {
		this.bqOpt1ImgID = bqOpt1ImgID;
	}
	@JsonProperty("blnqOption2ImgID")
	public BLNQImage getBqOpt2ImgID() {
		return bqOpt2ImgID;
	}
	@JsonProperty("blnqOption2ImgID")
	public void setBqOpt2ImgID(BLNQImage bqOpt2ImgID) {
		this.bqOpt2ImgID = bqOpt2ImgID;
	}
	@JsonProperty("blnqcreateBy")
	public String getBqCreatedBy() {
		return bqCreatedBy;
	}
	@JsonProperty("blnqcreateBy")
	public void setBqCreatedBy(String bqCreatedBy) {
		this.bqCreatedBy = bqCreatedBy;
	}
	@JsonProperty("blnqLastModifiedBy")
	public String getBqLastModBy() {
		return bqLastModBy;
	}
	@JsonProperty("blnqLastModifiedBy")
	public void setBqLastModBy(String bqLastModBy) {
		this.bqLastModBy = bqLastModBy;
	}
	@JsonProperty("blnqContextType")
	public String getBqContType() {
		return bqContType;
	}
	@JsonProperty("blnqContextType")
	public void setBqContType(String bqContType) {
		this.bqContType = bqContType;
	}
	@JsonProperty("blnqContextUrl")
	public String getBqContUrl() {
		return bqContUrl;
	}
	@JsonProperty("blnqContextUrl")
	public void setBqContUrl(String bqContUrl) {
		this.bqContUrl = bqContUrl;
	}
	@JsonProperty("blnqContextText")
	public String getBqContText() {
		return bqContText;
	}
	@JsonProperty("blnqContextText")
	public void setBqContText(String bqContText) {
		this.bqContText = bqContText;
	}
	@JsonProperty("blnqTimeOut")
	public int getBqTimeOut() {
		return bqTimeOut;
	}
	@JsonProperty("blnqTimeOut")
	public void setBqTimeOut(int bqTimeOut) {
		this.bqTimeOut = bqTimeOut;
	}
	@JsonProperty("blnqSeqNum")
	public int getBqSeqNum() {
		return bqSeqNum;
	}
	@JsonProperty("blnqSeqNum")
	public void setBqSeqNum(int bqSeqNum) {
		this.bqSeqNum = bqSeqNum;
	}
	@JsonProperty("blnqVersionId")
	public String getBqVerId() {
		return bqVerId;
	}
	@JsonProperty("blnqVersionId")
	public void setBqVerId(String bqVerId) {
		this.bqVerId = bqVerId;
	}
	@JsonProperty("blnqVerisoNum")
	public String getBqVerNum() {
		return bqVerNum;
	}
	@JsonProperty("blnqVerisoNum")
	public void setBqVerNum(String bqVerNum) {
		this.bqVerNum = bqVerNum;
	}
	@JsonProperty("blnqr")
	public BlnqBlnqr getBlnqr() {
		return mBlnqr;
	}
	@JsonProperty("blnqr")
	public void setBlnqr(BlnqBlnqr mBlnqr) {
		this.mBlnqr = mBlnqr;
	}
	@JsonProperty("feedback")
	public Feedback getBqFeedback() {
		return bqFeedback;
	}
	@JsonProperty("feedback")
	public void setBqFeedback(Feedback bqFeedback) {
		this.bqFeedback = bqFeedback;
	}
	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}
	@JsonAnySetter
	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}
	@JsonIgnore
	public MultipartFile getOption1Img() {
		return option1Img;
	}
	@JsonIgnore
	public void setOption1Img(MultipartFile option1Img) {
		this.option1Img = option1Img;
	}
	@JsonIgnore
	public MultipartFile getOption2Img() {
		return option2Img;
	}
	@JsonIgnore
	public void setOption2Img(MultipartFile option2Img) {
		this.option2Img = option2Img;
	}
	public Date getBqCreatedDate() {
		return bqCreatedDate;
	}
	public void setBqCreatedDate(Date bqCreatedDate) {
		this.bqCreatedDate = bqCreatedDate;
	}
	public String getBqId() {
		return bqId;
	}
	public void setBqId(String bqId) {
		this.bqId = bqId;
	}
	public boolean isOpt1Imgchanged() {
		return opt1Imgchanged;
	}
	public void setOpt1Imgchanged(boolean opt1Imgchanged) {
		this.opt1Imgchanged = opt1Imgchanged;
	}
	public boolean isOpt2Imgchanged() {
		return opt2Imgchanged;
	}
	public void setOpt2Imgchanged(boolean opt2Imgchanged) {
		this.opt2Imgchanged = opt2Imgchanged;
	}
	public String getOldOpt1ImgId() {
		return oldOpt1ImgId;
	}
	public void setOldOpt1ImgId(String oldOpt1ImgId) {
		this.oldOpt1ImgId = oldOpt1ImgId;
	}
	public String getOldOpt2ImgId() {
		return oldOpt2ImgId;
	}
	public void setOldOpt2ImgId(String oldOpt2ImgId) {
		this.oldOpt2ImgId = oldOpt2ImgId;
	}
	
}

