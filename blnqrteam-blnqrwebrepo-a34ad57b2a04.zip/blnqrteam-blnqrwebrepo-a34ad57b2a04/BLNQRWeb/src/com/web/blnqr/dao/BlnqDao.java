package com.web.blnqr.dao;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.internal.MultiPartWriter;
import org.json.JSONObject;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.web.blnqr.model.BLNQ;
import com.web.blnqr.model.BLNQImage;
import com.web.blnqr.model.BlnqrMessage;
import com.web.blnqr.model.Feedback;
import com.web.blnqr.model.ResponseMessage;
import com.web.blnqr.model.BlnqBlnqr;

public class BlnqDao {
	public static final String CREATE_BLNQ = "http://localhost:8080/BLNQRWS/blnq/createBlnq";
	public static final String CREATE_BLNQR_FILE = "http://localhost:8080/BLNQRWS/file/add";
	public static final String DELETE_BLNQR_FILE = "http://localhost:8080/BLNQRWS/file/%s/delete";
	public static final String GET_BLNQ = "http://localhost:8080/BLNQRWS/blnq/get";
	public static final String GET_BLNQR_FILE = "http://localhost:8080/BLNQRWS/file";
	public static final String UPDATE_BLNQ = "http://localhost:8080/BLNQRWS/blnq/updateBlnq";

	public ResponseMessage createBlnq(BLNQ blnq) {
		try {
			if (blnq != null) {

				MultipartFile Opt1file = blnq.getOption1Img();
				MultipartFile Opt2file = blnq.getOption2Img();
				if (!Opt1file.isEmpty()) {
					BlnqrMessage message = new BlnqrDao().createFile(Opt1file);
					if (message != null && message.getID() != null && !message.getID().trim().equals("")) {
						blnq.setBqOpt1ImgID(new BLNQImage(message.getID()));
					} else {
						return null;
					}
				}
				if (!Opt2file.isEmpty()) {
					BlnqrMessage message = new BlnqrDao().createFile(Opt2file);
					if (message != null && message.getID() != null && !message.getID().trim().equals("")) {
						blnq.setBqOpt2ImgID(new BLNQImage(message.getID()));
					} else {
						return null;
					}
				}

				blnq.setBqCreatedBy("Sunny");
				blnq.setBqLastModBy("Sunny");
				blnq.setBlnqr(new BlnqBlnqr("aea344f8-ae0d-4e15-aa48-8a683c5a7028"));
				blnq.setBqVerNum("121323");
				blnq.setBqVerId("v12.12");
				blnq.setBqSeqNum(1);

				Client client = ClientBuilder.newClient();
				WebTarget target = client.target(CREATE_BLNQ);
				Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
						.header("token", "12345").post(Entity.json(blnq));
				if (response.getStatus() == 200) {
					ResponseMessage message = response.readEntity(ResponseMessage.class);
					System.out.println("data : " + message);
					return message;
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in Create Blnq!");
			e.printStackTrace();
		}
		return null;
	}

	public BlnqrMessage createFile(MultipartFile file) {
		try {
			FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
			FormDataBodyPart bodyPart = new FormDataBodyPart("file", new ByteArrayInputStream(file.getBytes()),
					MediaType.APPLICATION_OCTET_STREAM_TYPE);
			formDataMultiPart.field("file", file.getInputStream(), MediaType.MULTIPART_FORM_DATA_TYPE);
			FormDataContentDisposition dispo = FormDataContentDisposition.name("file")
					.fileName(file.getOriginalFilename()).size(file.getBytes().length).build();
			formDataMultiPart.bodyPart(bodyPart);
			bodyPart.setFormDataContentDisposition(dispo);
			ClientConfig config = new ClientConfig();
			config.register(MultiPartWriter.class);
			Client client = ClientBuilder.newClient(config);
			WebTarget target = client.target(CREATE_BLNQR_FILE);
			Response response = target.request(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON)
					.header("token", "12345").header("Content-Type", MediaType.MULTIPART_FORM_DATA)
					.property("file", formDataMultiPart)
					.post(Entity.entity(formDataMultiPart, MediaType.MULTIPART_FORM_DATA_TYPE));
			if (response.getStatus() == 200) {
				System.out.println("File Create Status : " + response.getStatus());
				BlnqrMessage message = response.readEntity(BlnqrMessage.class);
				System.out.println("data : " + message);
				return message;
			} else {
				System.out.println("File Create Status : " + response.getStatus());
			}
		} catch (Exception e) {
			System.out.println("Got Exception in Create file");
			e.printStackTrace();
		}
		return null;
	}

	public BLNQ getBlnq() {
		return null;
	}

	// need to verify
	public Boolean deleteFile(String id) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(String.format(DELETE_BLNQR_FILE, id));
		Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
				.header("token", "12345").post(null); 
		ResponseMessage message = response.readEntity(ResponseMessage.class);
		// System.out.println("data : "+message);
		if(response.getStatus() == 200) {
			System.out.println("Deleted Successfully :"+message);
			return true;
		}
		return false;
	}

	public ResponseMessage editBlnq(BLNQ blnq) {
		try {
			if (blnq != null) {
				MultipartFile Opt1file = blnq.getOption1Img();
				MultipartFile Opt2file = blnq.getOption2Img();
				if (blnq.isOpt1Imgchanged()) {
					if (!Opt1file.isEmpty()) {
						BlnqrMessage message = new BlnqrDao().createFile(Opt1file);
						if (message != null && message.getID() != null && !message.getID().trim().equals("")) {
							blnq.setBqOpt1ImgID(new BLNQImage(message.getID()));
//							if(!deleteFile(blnq.getOldOpt1ImgId())) {
//								return null;
//							}
						} else {
							return null;
						}
					}
				} else 
					blnq.setBqOpt1ImgID(new BLNQImage(blnq.getOldOpt1ImgId()));
				if (blnq.isOpt2Imgchanged()) {
					if (!Opt2file.isEmpty()) {
						BlnqrMessage message = new BlnqrDao().createFile(Opt2file);
						if (message != null && message.getID() != null && !message.getID().trim().equals("")) {
							blnq.setBqOpt2ImgID(new BLNQImage(message.getID()));
							deleteFile(blnq.getOldOpt1ImgId());
//							if(!deleteFile(blnq.getOldOpt1ImgId())) {
//								return null;
//							}
						} else {
							return null;
						}
					}
				} else 
					blnq.setBqOpt2ImgID(new BLNQImage(blnq.getOldOpt2ImgId()));
				blnq.setBqCreatedBy("Sunny");
				blnq.setBqLastModBy("Sunny");
				blnq.setBlnqr(new BlnqBlnqr("aea344f8-ae0d-4e15-aa48-8a683c5a7028"));
				blnq.setBqVerNum("121323");
				blnq.setBqVerId("v12.12");
				blnq.setBqSeqNum(1);

				Client client = ClientBuilder.newClient();
				WebTarget target = client.target(UPDATE_BLNQ);
				Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
						.header("token", "12345").post(Entity.json(blnq));
				if (response.getStatus() == 200) {
					ResponseMessage message = response.readEntity(ResponseMessage.class);
					System.out.println("data : " + message);
					return message;
				}
			}
		} catch (Exception e) {
			System.out.println("Exception in Create Blnq!");
			e.printStackTrace();
		}
		return null;
	}

	public BLNQ getBlnq(String id) {
		try { 
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(GET_BLNQ);
			Response response = target.queryParam("id", id).request(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON).header("token", "12345").get();
			if (response.getStatus() == 200) {
				BLNQ mBlnq = gernateBLNQ(response.readEntity(String.class));
				return mBlnq;
			}
		} catch (Exception e) {
			System.out.println("Got Exception in get Blnqr!");
		}
		return null;
	}

	public BLNQ gernateBLNQ(String response) throws ParseException {
		BLNQ mBLNQ = new BLNQ();
		JSONObject mJson = new JSONObject(response);
		if (mJson.has("blnqQuestion"))
			mBLNQ.setBqQue(mJson.getString("blnqQuestion"));
		if (mJson.has("blnqOption1"))
			mBLNQ.setBqOpt1(mJson.getString("blnqOption1"));
		if (mJson.has("blnqOption2"))
			mBLNQ.setBqOpt2(mJson.getString("blnqOption2"));
		if (mJson.has("blnqContextText"))
			mBLNQ.setBqContText(mJson.getString("blnqContextText"));
		if (mJson.has("blnqContextType"))
			mBLNQ.setBqContType(mJson.getString("blnqContextType"));
		if (mJson.has("blnqContextUrl"))
			mBLNQ.setBqContUrl(mJson.getString("blnqContextUrl"));
		if (mJson.has("blnqcreateBy"))
			mBLNQ.setBqCreatedBy(mJson.getString("blnqcreateBy"));
		if (mJson.has("blnqLastModifiedBy"))
			mBLNQ.setBqLastModBy(mJson.getString("blnqLastModifiedBy"));
		if (mJson.has("blnqSeqNum"))
			mBLNQ.setBqSeqNum(mJson.getInt("blnqSeqNum"));
		if (mJson.has("blnqTimeOut"))
			mBLNQ.setBqTimeOut(mJson.getInt("blnqTimeOut"));
		if (mJson.has("blnqVersionId"))
			mBLNQ.setBqVerId(mJson.getString("blnqVersionId"));
		if (mJson.has("blnqVerisoNum"))
			mBLNQ.setBqVerNum(mJson.getString("blnqVerisoNum"));
		if (mJson.has("blnqCreatedDate"))
			mBLNQ.setBqCreatedDate(
					(Date) new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy").parse(mJson.getString("blnqCreatedDate")));
		if (mJson.has("option1ImgId")) {
			mBLNQ.setOption1Img(getBLFile(mJson.getString("option1ImgId"))); 
			mBLNQ.setOldOpt1ImgId(mJson.getString("option1ImgId"));}
		if (mJson.has("option2ImgId")) {
			mBLNQ.setOption2Img(getBLFile(mJson.getString("option2ImgId"))); 
			mBLNQ.setOldOpt2ImgId(mJson.getString("option2ImgId"));}
		if (mJson.has("feedback")) {
			JSONObject mFBJson = mJson.getJSONObject("feedback");
			Feedback mFeedback = new Feedback();
			if (mFBJson.has("displayFlag"))
				mFeedback.setDisplayFlag(mFBJson.getBoolean("displayFlag"));
			if (mFBJson.has("feedText"))
				mFeedback.setFeedText(mFBJson.getString("feedText"));
			if (mFBJson.has("feedType"))
				mFeedback.setFeedType(mFBJson.getString("feedType"));
			mBLNQ.setBqFeedback(mFeedback);
		}
		if (mJson.has("blnqr")) {
			JSONObject mBQR = new JSONObject(mJson.getJSONObject("blnqr"));
			if (mBQR.has("blnqrID"))
				mBLNQ.setBlnqr(new BlnqBlnqr(mBQR.getString("blnqrID")));
		}
		return mBLNQ;
	}

	public MultipartFile getBLFile(String id) {
		try {
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(GET_BLNQR_FILE).path("{id}/get").resolveTemplate("id", id);
			Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
					.header("token", "12345").get();
			if (response.getStatus() == 200) {
				String json = response.readEntity(String.class);
				JSONObject object = new JSONObject(json);
				String encoded = object.get("data").toString();
				byte[] data = org.apache.commons.codec.binary.Base64.decodeBase64(encoded);
				InputStream is = new ByteArrayInputStream(data);
				MultipartFile result = new MockMultipartFile(String.valueOf(object.get("fileName")),
						String.valueOf(object.get("fileName")), String.valueOf(object.get("fileMimeType")), is);
				return result;
			}
		} catch (Exception e) {
			System.out.println("Got Exception in get BLNQ Image!");
		}
		return null;
	}
}