package com.web.blnqr.dao;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.internal.util.Base64;
import org.glassfish.jersey.media.multipart.ContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.internal.MultiPartWriter;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.blnqr.entity.BLFILE;
import com.blnqr.entity.BLNQR;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.web.blnqr.model.Blnqr;
import com.web.blnqr.model.BlnqrMessage;
import com.web.blnqr.model.Feedback;
import com.web.blnqr.model.Message;

public class BlnqrDao {
	String createURL = "http://localhost:8080/BLNQRWS/blnqr/createBlnqr";
	String createFileURL = "http://localhost:8080/BLNQRWS/file/add";
	String deleteFileURL = "http://localhost:8080/BLNQRWS/file/%1/delete";
	String getFileURL = "http://localhost:8080/BLNQRWS/file";
	String getBlnqr = "http://localhost:8080/BLNQRWS/blnqr/get";
	String updateBlnqrURL = "http://localhost:8080/BLNQRWS/blnqr/updateBlnqr";
	
	public BlnqrMessage createBlnqr(Blnqr blnqr){
		try{
			if(blnqr != null){
				MultipartFile file = blnqr.getBlnqrIcon();
				if(file!=null&&file.getBytes().length>0){
					BlnqrMessage message = new BlnqrDao().createFile(file);
					if(message!=null && message.getID()!=null && !message.getID().trim().equals("")){
						blnqr.setBlnqrIconId(message.getID());
					}else{
						return null;
					}
				}
				if(blnqr.getSearchTerms()!=null && blnqr.getSearchTerms().length()>0)
				{
					String searchTermString = blnqr.getSearchTerms();
					if(searchTermString !=null && !searchTermString.trim().equals("")){
						searchTermString = searchTermString.trim();
						List<String> searchTerms = new ArrayList<String>();
						String[] searchTermsArray = searchTermString.split("[\\r\\n]");
						for(String term : searchTermsArray){
							if(!term.trim().equals("")){
								searchTerms.add(term.trim());
							}
						}
						blnqr.setBlnqrsearchTerms(searchTerms);
					}
				}
				Client client = ClientBuilder.newClient();
				WebTarget target = client.target(createURL);
				Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).header("token", "12345").post(Entity.json(blnqr));
				if(response.getStatus() == 200){
					BlnqrMessage message = response.readEntity(BlnqrMessage.class);
					System.out.println("data : "+message);
					return message;
				}else{
					if(blnqr.getBlnqrIconId() != null && !blnqr.getBlnqrIconId().trim().equals("")){
						deleteFile(blnqr.getBlnqrIconId());
					}
				}
			}
		}catch(Exception e){
			if(blnqr != null && blnqr.getBlnqrIconId() != null && !blnqr.getBlnqrIconId().trim().equals("")){
				deleteFile(blnqr.getBlnqrIconId());
			}
			System.out.println("Exception in Create Blnqr!");
			e.printStackTrace();
		}
		return null;
	}
	
	public BlnqrMessage createFile(MultipartFile file){
		try{
			 //File f=new File(file.getName());
			 //file.transferTo(new File(file.getOriginalFilename()));
			FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
			String s[]=file.getContentType().split("/");
			FormDataBodyPart bodyPart = new FormDataBodyPart("file",
		            new ByteArrayInputStream(file.getBytes()),
		            new MediaType(s[0],s[1]));
			
			
			
			//bodyPart.setMediaType(new MediaType(file.getContentType(),file.getContentType()));	
			formDataMultiPart.field("file",file.getInputStream() , MediaType.MULTIPART_FORM_DATA_TYPE);
			FormDataContentDisposition dispo = FormDataContentDisposition
			        .name("file")//
			        .fileName(file.getOriginalFilename())//
			        .size(file.getBytes().length)//
			        
			        .build();
			 formDataMultiPart.bodyPart(bodyPart);
			 bodyPart.setFormDataContentDisposition(dispo);
			//formDataMultiPart.contentDisposition(dispo);
			ClientConfig config =  new ClientConfig();
			//config.getClasses().add(MultiPartWriter.class);
			config.register(MultiPartWriter.class);
			Client client = ClientBuilder.newClient(config);
			WebTarget target = client.target(createFileURL);
			Response response = target.request(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON).header("token", "12345").header("Content-Type", MediaType.MULTIPART_FORM_DATA).property("file", formDataMultiPart).post(Entity.entity(formDataMultiPart, MediaType.MULTIPART_FORM_DATA_TYPE));
			if(response.getStatus() == 200){
				System.out.println("File Create Status : "+response.getStatus());
				BlnqrMessage message = response.readEntity(BlnqrMessage.class);
				System.out.println("data : "+message);
			return message;
			}else{
				System.out.println("File Create Status : "+response.getStatus());
			}
		}catch(Exception e){
			System.out.println("Got Exception in Create file");
			e.printStackTrace();
		}
		return null;
	}
	public BlnqrMessage updateFile(MultipartFile file,String id){
		try{
			 //File f=new File(file.getName());
			 //file.transferTo(new File(file.getOriginalFilename()));
			FormDataMultiPart formDataMultiPart = new FormDataMultiPart();
			String s[]=file.getContentType().split("/");
			FormDataBodyPart bodyPart = new FormDataBodyPart("file",
		            new ByteArrayInputStream(file.getBytes()),
		            new MediaType(s[0],s[1]));
			
			
			
			//bodyPart.setMediaType(new MediaType(file.getContentType(),file.getContentType()));	
			formDataMultiPart.field("file",file.getInputStream() , MediaType.MULTIPART_FORM_DATA_TYPE);
			FormDataContentDisposition dispo = FormDataContentDisposition
			        .name("file")//
			        .fileName(file.getOriginalFilename())//
			        .size(file.getBytes().length)//
			        
			        .build();
			 formDataMultiPart.bodyPart(bodyPart);
			 formDataMultiPart.field("fileId", id);
			 bodyPart.setFormDataContentDisposition(dispo);
			//formDataMultiPart.contentDisposition(dispo);
			ClientConfig config =  new ClientConfig();
			//config.getClasses().add(MultiPartWriter.class);
			config.register(MultiPartWriter.class);
			Client client = ClientBuilder.newClient(config);
			WebTarget target = client.target(getFileURL).path("update");
			Response response = target.request(MediaType.MULTIPART_FORM_DATA).accept(MediaType.APPLICATION_JSON).header("token", "12345").header("Content-Type", MediaType.MULTIPART_FORM_DATA).property("file", formDataMultiPart).post(Entity.entity(formDataMultiPart, MediaType.MULTIPART_FORM_DATA_TYPE));
			if(response.getStatus() == 200){
				System.out.println("File update Status : "+response.getStatus());
				BlnqrMessage message = response.readEntity(BlnqrMessage.class);
				System.out.println("data : "+message);
			return message;
			}else{
				System.out.println("File update Status : "+response.getStatus());
			}
		}catch(Exception e){
			System.out.println("Got Exception in update file");
			e.printStackTrace();
		}
		return null;
	}
	public Blnqr getBlnqr(String id, String name, String location){
		try{
			Client client = ClientBuilder.newClient();
			Blnqr blnqr=new Blnqr();
			WebTarget target = client.target(getBlnqr);
			Response response = target.queryParam("id", id).queryParam("name", name).queryParam("location", location).request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).header("token", "12345").get();
			if(response.getStatus() == 200){
				BLNQR b = response.readEntity(BLNQR.class);
				blnqr.setBlnqrID(b.getBlnqrID());
				blnqr.setBlnqrIconId(b.getBlnqrIcon());
				blnqr.setBlnqrLocation(b.getBlnqrLocation());
				StringBuilder searchTerms = new StringBuilder();
				if(b.getBlnqrsearchTerms() != null){
					for(String term : b.getBlnqrsearchTerms()){
						searchTerms.append(term);
						searchTerms.append("\r\n");
					}
				}
				blnqr.setSearchTerms(searchTerms.toString());
				blnqr.setBlnqrName(b.getBlnqrName());
				Feedback f=new Feedback();
				f.setDisplayFlag(b.getFeedback().isDisplayFlag());
				//if(f.isDisplayFlag()){
					f.setFeedText(b.getFeedback().getFeedText());
					f.setFeedType(b.getFeedback().getFeedType());
				//}
				Message msg=new Message();
				msg.setDisplayFlag(b.getMessage().isDisplayFlag());
				//if(msg.isDisplayFlag()){
					msg.setBtnCancelText(b.getMessage().getBtnCancelText());
					msg.setBtnOKText(b.getMessage().getBtnOKText());
					msg.setMsgHeader(b.getMessage().getMsgHeader());
					msg.setMsgText(b.getMessage().getMsgText());
				//}
				blnqr.setFeedback(f);
				blnqr.setMessage(msg);
				blnqr.setBlnqrIcon(new BlnqrDao().getBLFIle(b.getBlnqrIcon()));
				return blnqr;
			}
		}catch(Exception e){
			System.out.println("Got Exception in get Blnqr!");
		}
		return null;
	}
	public MultipartFile getBLFIle(String id){
		try{
			Client client = ClientBuilder.newClient();
			WebTarget target = client.target(getFileURL).path("{id}/get").resolveTemplate("id", id);
			Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).header("token", "12345").get();
			
			if(response.getStatus() == 200){
				
				String  json = response.readEntity(String.class);
				
				JSONObject object=new JSONObject(json);
				String encoded =object.get("data").toString();
				byte[] data = org.apache.commons.codec.binary.Base64.decodeBase64(encoded);
				
				
				//BLFILE file = response.readEntity(BLFILE.class);
				
				//System.out.println((object.get("fileData").toString()).length());
				//byte[] data=
				InputStream is =new ByteArrayInputStream(data); ;
				MultipartFile result = new MockMultipartFile(String.valueOf(object.get("fileName")),
						String.valueOf(object.get("fileName")), String.valueOf(object.get("fileMimeType")), is);
				
				return result;
			}
		}catch(Exception e){
			System.out.println("Got Exception in get Icon!");
		}
		return null;
	}
	
	
	//need to verify
	public BlnqrMessage deleteFile(String id){
		Client client = ClientBuilder.newClient();
		WebTarget target = client.target(String.format(deleteFileURL, id));
		Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).header("token", "12345").post((Entity<?>) new Object());
		BlnqrMessage message = response.readEntity(BlnqrMessage.class);
		System.out.println("data : "+message);
		return message;
	}
	
	//not completed yet need to do
	public BlnqrMessage updateBlnqr(Blnqr blnqr){
		try{
			BlnqrMessage message ;
			if(blnqr != null){
				if(blnqr.getBlnqrID() != null && !blnqr.getBlnqrID().trim().equals("")){
					if(blnqr.isUpdateIcon()){
						MultipartFile file = blnqr.getBlnqrIcon();
						if(file != null && file.getBytes().length > 0){
							if(blnqr.getBlnqrIconId() != null && !blnqr.getBlnqrIconId().trim().equals("")){
								message = new BlnqrDao().updateFile(blnqr.getBlnqrIcon(),blnqr.getBlnqrIconId());
							}else{																			//in case blnqr didn't had an icon before
								message = new BlnqDao().createFile(blnqr.getBlnqrIcon());
								if(message != null && message.getId() != null && !message.getId().trim().equals("")){
									blnqr.setBlnqrIconId(message.getId().trim());
								}
							}
						}
					}
					
					if(blnqr.getSearchTerms()!=null && blnqr.getSearchTerms().length()>0)
					{
						String searchTermString = blnqr.getSearchTerms();
						if(searchTermString !=null && !searchTermString.trim().equals("")){
							searchTermString = searchTermString.trim();
							List<String> searchTerms = new ArrayList<String>();
							String[] searchTermsArray = searchTermString.split("[\\r\\n]");
							for(String term : searchTermsArray){
								if(!term.trim().equals("")){
									searchTerms.add(term.trim());
								}
							}
							blnqr.setBlnqrsearchTerms(searchTerms);
						}
					}
					Client client = ClientBuilder.newClient();
					WebTarget target = client.target(updateBlnqrURL);
					Response response = target.request(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).header("token", "12345").post(Entity.json(blnqr));
					if(response.getStatus() == 200){
						message = response.readEntity(BlnqrMessage.class);
						System.out.println("data : "+message);
						return message;
					}
				}
			}
			
		}catch(Exception e){
			System.out.println("Exception in update Blnqr!");
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) {
		BlnqrDao blnqrDao = new BlnqrDao();
		Blnqr blnqr = new Blnqr();
		Feedback feedback = new Feedback();
		//feedback.setDisplayFlag("true");
		feedback.setFeedText("feed text");
		feedback.setFeedType("feed type");
		Message message = new Message();
		message.setBtnCancelText("cancel");
		message.setBtnOKText("ok");
		//message.isDisplayFlag("true");
		message.setMsgHeader("msg header");
		message.setMsgText("msg text");
		blnqr.setBlnqrName("hello");
		//blnqr.setBlnqrIcon("testid");
		blnqr.setFeedback(feedback);
		blnqr.setMessage(message);
		
		BlnqrMessage blnqrMessage = blnqrDao.createBlnqr(blnqr);
	}
}
