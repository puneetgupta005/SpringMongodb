/**
 * Created by - Amardeep Kumar
 * Date - 10-April-2017
 */

/**
* code for image upload using drag and drop for blnqr
**/

// $(function(){
// 	var globalFile = null;
// 	var dropArea = $("#dropArea");
// 	dropArea.on("dragover", function(e){
// 		e.stopPropagation();
// 		e.preventDefault();
// 		$(this).css("border","2px solid #2980b9");
// 	});
	
// 	dropArea.on("drop", function(e){
// 		e.stopPropagation();
// 		e.preventDefault();
// 		$(this).css("border","1px dotted #95a5a6");
// 		var files = e.originalEvent.dataTransfer.files;
// 		var iconFile = files[0];
// 		if(isImageFile(iconFile)){
// 			globalFile = iconFile;
// 			console.log(iconFile);
// 			$("#before-upload").hide();
// 			$("#after-upload").show();
// 			$("#icon-preview-div").html("<img id='icon-img' class='icon-img'/>");
// 			$('#close').tooltip();
// 			var reader = new FileReader();
// 		    reader.onload = function(){
// 		      var dataURL = reader.result;
// 		      $("#icon-img").attr("src",dataURL);
// 		    };
// 		    reader.readAsDataURL(iconFile);
// 		   // uploadFile(iconFile);
// 		}else{
// 			alert("Upload Only Image File!");
// 		}
// 	});
	
// 	var iconInput = $("#icon-input");
// 	iconInput.on("change",function(e){
// 		var inputFiles = iconInput[0].files;
		
// 		console.log(iconInput.files);
// 		if(inputFiles !== null && inputFiles.length >0){
// 			var inputFile = inputFiles[0];
// 			if(isImageFile(inputFile)){
// 				globalFile = inputFile;
// 				console.log(inputFile);
// 				$("#before-upload").hide();
// 				$("#after-upload").show();
// 				$("#icon-preview-div").html("<img id='icon-img' class='icon-img'/>");
// 				$('#close').tooltip();
// 				var reader = new FileReader();
// 				reader.onload = function(){
// 					var dataURL = reader.result;
// 					$("#icon-img").attr("src",dataURL);
// 				};
// 				reader.readAsDataURL(inputFile);
// 				//uploadImage()
// 			}else{
// 				alert("Upload Only Image File!");
// 				$("#icon-input").val("");
// 			}        
// 		}
		
// 	});
	
// 	$("#close").on("click", function(e){
// 		$("#before-upload").show();
// 		$("#icon-input").val("");
// 		$("#after-upload").hide();
// 		globalFile = null;
// 	});
	
	
// });

$(function(){
	var globalFile = null;
	var dropArea = $("#dropAreaopt1");
	dropArea.on("dragoveropt1", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","2px solid #2980b9");
	});
	
	dropArea.on("drop", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","1px dotted #95a5a6");
		var files = e.originalEvent.dataTransfer.files;
		var iconFile = files[0];
		if(isImageFile(iconFile)){
			globalFile = iconFile;
			console.log(iconFile);
			$("#before-uploadopt1").hide();
			$("#after-uploadopt1").show();
			$("#icon-preview-divopt1").html("<img id='icon-imgopt1' class='icon-img'/>");
			$('#closeopt1').tooltip();
			$('#opt1Imgchanged').val('true');
			var reader = new FileReader();
		    reader.onload = function(){
		      var dataURL = reader.result;
		      $("#icon-imgopt1").attr("src",dataURL);
		    };
		    reader.readAsDataURL(iconFile);
		   // uploadFile(iconFile);
		}else{
			alert("Upload Only Image File!");
		}
	});
	
	var iconInput = $("#Opt1Img");
	iconInput.on("change",function(e){
		var inputFiles = iconInput[0].files;
		
		console.log(iconInput.files);
		if(inputFiles !== null && inputFiles.length >0){
			var inputFile = inputFiles[0];
			if(isImageFile(inputFile)){
				globalFile = inputFile;
				console.log(inputFile);
				$("#before-uploadopt1").hide();
				$("#after-uploadopt1").show();
				$("#icon-preview-divopt1").html("<img id='icon-img' class='icon-img'/>");
				$('#close').tooltip();
				$('#opt1Imgchanged').val('true');
				var reader = new FileReader();
				reader.onload = function(){
					var dataURL = reader.result;
					$("#icon-imgopt1").attr("src",dataURL);
				};
				reader.readAsDataURL(inputFile);
				//uploadImage()
			}else{
				alert("Upload Only Image File!");
				$("#Opt1Img").val("");
			}        
		}
		
	});
	
	$("#close").on("click", function(e){
		$("#before-upload").show();
		$("#icon-input").val("");
		$("#after-upload").hide();
		globalFile = null;
	});
	
	
});

$(function(){
	var globalFile = null;
	var dropArea = $("#dropAreaopt2");
	dropArea.on("dragoveropt2", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","2px solid #2980b9");
	});
	
	dropArea.on("drop", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","1px dotted #95a5a6");
		var files = e.originalEvent.dataTransfer.files;
		var iconFile = files[0];
		if(isImageFile(iconFile)){
			globalFile = iconFile;
			console.log(iconFile);
			$("#before-uploadopt2").hide();
			$("#after-uploadopt2").show();
			$("#icon-preview-divopt2").html("<img id='icon-imgopt1' class='icon-img'/>");
			$('#closeopt2').tooltip();
			$('#opt2Imgchanged').val('true');
			var reader = new FileReader();
		    reader.onload = function(){
		      var dataURL = reader.result;
		      $("#icon-imgopt2").attr("src",dataURL);
		    };
		    reader.readAsDataURL(iconFile);
		   // uploadFile(iconFile);
		}else{
			alert("Upload Only Image File!");
		}
	});
	
	var iconInput = $("#Opt2Img");
	iconInput.on("change",function(e){
		var inputFiles = iconInput[0].files;
		
		console.log(iconInput.files);
		if(inputFiles !== null && inputFiles.length >0){
			var inputFile = inputFiles[0];
			if(isImageFile(inputFile)){
				globalFile = inputFile;
				console.log(inputFile);
				$("#before-uploadopt2").hide();
				$("#after-uploadopt2").show();
				$("#icon-preview-divopt2").html("<img id='icon-img' class='icon-img'/>");
				$('#close').tooltip();
				$('#opt2Imgchanged').val('true');
				var reader = new FileReader();
				reader.onload = function(){
					var dataURL = reader.result;
					$("#icon-imgopt2").attr("src",dataURL);
				};
				reader.readAsDataURL(inputFile);
				//uploadImage()
			}else{
				alert("Upload Only Image File!");
				$("#Opt1Img").val("");
			}        
		}
		
	});
	
	$("#close").on("click", function(e){
		$("#before-upload").show();
		$("#icon-input").val("");
		$("#after-upload").hide();
		globalFile = null;
	});
	
	
});


function isImageFile(file){
	var type = file.type;
	var res = type.match(/image\//g);
	if(res == null || res == undefined){
		return  false;
	}else{
		return true;
	}
}

function uploadImage(){
	
}