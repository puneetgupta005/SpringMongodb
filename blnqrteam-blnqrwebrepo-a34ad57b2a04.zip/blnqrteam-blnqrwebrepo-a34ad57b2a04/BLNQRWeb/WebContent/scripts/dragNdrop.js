/**
 * Created by - Amardeep Kumar
 * Date - 10-April-2017
 */

/**
* code for image upload using drag and drop for blnqr
**/

var globalFile = null;
var isDragNDrop = false;
$(function(){
	var dropArea = $("#dropArea");
	//alert("hellO000");
	dropArea.on("dragover", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","2px solid #2980b9");
	});
	
	dropArea.on("drop", function(e){
		e.stopPropagation();
		e.preventDefault();
		$(this).css("border","1px dotted #95a5a6");
		var files = e.originalEvent.dataTransfer.files;
		var iconFile = files[0];
		if(isImageFile(iconFile)){
			globalFile = iconFile;
			isDragNDrop = true;
			console.log(iconFile);
			$("#before-upload").hide();
			$("#after-upload").show();
			$("#icon-preview-div").html("<img id='icon-img' class='icon-img'/>");
			$('#close').tooltip();
			var reader = new FileReader();
		    reader.onload = function(){
		      var dataURL = reader.result;
		      $("#icon-img").attr("src",dataURL);
		    };
		    reader.readAsDataURL(iconFile);
		   // uploadFile(iconFile);
		}else{
			alert("Upload Only Image File!")
		}
	});
	
	var iconInput = $("#icon-input");
	iconInput.on("change",function(e){
		var inputFiles = iconInput[0].files;
		
		console.log(iconInput.files);
		if(inputFiles != null && inputFiles.length >0){
			var inputFile = inputFiles[0];
			if(isImageFile(inputFile)){
				globalFile = inputFile;
				isDragNDrop = false;
				console.log(inputFile);
				$("#before-upload").hide();
				$("#after-upload").show();
				$("#icon-preview-div").html("<img id='icon-img' class='icon-img'/>");
				$('#close').tooltip();
				var reader = new FileReader();
				reader.onload = function(){
					var dataURL = reader.result;
					$("#icon-img").attr("src",dataURL);
				};
				reader.readAsDataURL(inputFile);
				//uploadImage()
			}else{
				alert("Upload Only Image File!");
				$("#icon-input").val("");
			}        
		}
		
	});
	
	
	$("#close").on("click", function(e){
		$("#before-upload").show();
		$("#icon-input").val("");
		$("#after-upload").hide();
		globalFile = null;
	});
	
	
});

function isImageFile(file){
	var type = file.type;
	var res = type.match(/image\//g);
	if(res == null || res == undefined){
		return  false;
	}else{
		return true;
	}
}

function uploadImage(){
	
}
function loadImage(){
	var iconInput = $("#icon-input");
	var inputFiles = iconInput[0].files;
		console.log(iconInput.files);
		if(inputFiles != null && inputFiles.length >0){
			var inputFile = inputFiles[0];
			if(isImageFile(inputFile)){
				globalFile = inputFile;
				console.log(inputFile);
				$("#before-upload").hide();
				$("#after-upload").show();
				$("#icon-preview-div").html("<img id='icon-img' class='icon-img'/>");
				$('#close').tooltip();
				var reader = new FileReader();
				reader.onload = function(){
					var dataURL = reader.result;
					$("#icon-img").attr("src",dataURL);
				};
				reader.readAsDataURL(inputFile);
				//uploadImage()
			}else{
				alert("Upload Only Image File!");
				$("#icon-input").val("");
			}        
		}
		
	
}