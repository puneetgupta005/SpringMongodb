/**
 * @author Amardeep Kumar
 * May-10-2017
 */
var updateImage = false;
var oldFile = null;

$(function(){
	$("#disp-msg").on("click",function(e){
		if($(this).is(":checked")){
			$("#msg-txt-req").show();
			$("#msg-head-req").show();
			$("#msg-head-ip").attr("required","required");
			$("#msg-txt-ip").attr("required","required");
		}else{
			$("#msg-txt-req").hide();
			$("#msg-head-req").hide();
			$("#msg-head-ip").removeAttr("required");
			$("#msg-txt-ip").removeAttr("required");
		}
	});
	
	$("#ok-btn-txt").on("change",function(e){
		if(isValid($(this).val())){
			$("#cancel-btn-txt").attr("required","required");
		}else{
			$("#cancel-btn-txt").removeAttr("required");
		}
	});
	
	$("#cancel-btn-txt").on("change",function(){
		if(isValid($(this).val())){
			$("#ok-btn-txt").attr("required","required");
		}else{
			$("#ok-btn-txt").removeAttr("required");
		}
	});
	
	$("#disp-feed").on("click",function(e){
		if($(this).is(":checked")){
			$("#feed-type-req").show();
			$("#feed-txt-req").show();
			$("#feed-type-ip").attr("required", "required");
			$("#feed-txt-ip").attr("required", "required");
		}else{
			$("#feed-type-req").hide();
			$("#feed-txt-req").hide();
			$("#feed-type-ip").removeAttr("required");
			$("#feed-txt-ip").removeAttr("required");
		}
	});
	
	$("#msg-down-arrow").parent().on("click",function(){
		if($("#msg-down-arrow").hasClass("transformed")){
			$("#msg-down-arrow").css("transform","");
			$("#msg-down-arrow").removeClass("transformed");
		}else{
			$("#msg-down-arrow").css("transform","rotate(180deg)");
			$("#msg-down-arrow").addClass("transformed");
		}
	});
	$("#feed-down-arrow").parent().on("click",function(){
		if($("#feed-down-arrow").hasClass("transformed")){
			$("#feed-down-arrow").css("transform","");
			$("#feed-down-arrow").removeClass("transformed");
		}else{
			$("#feed-down-arrow").css("transform","rotate(180deg)");
			$("#feed-down-arrow").addClass("transformed");
		}
	});
});

if(globalFile == null){
	$("#save-img-btn").prop("disabled",true);
}
$(function(){
	oldFile = $(".image-view").attr("src");
	$("#change-img-checkbox").on("click",function(){
		if($(this).is(":checked")){
			updateImage = true;
			$("#myModal").modal({show:true,backdrop:'static'});
		}else{
			updateImage = false;
			$("#icon-input").val(null);
			$("#before-upload").show();
			$("#after-upload").hide();
			globalFile = null;
			$(".image-view").attr("src",oldFile);
		}
	});
	
	$("#modal-close-btn").on("click",function(){
		$("#myModal").modal("hide");
		if(globalFile == null){
			$("#change-img-checkbox").prop("checked",false);
		}else{
			globalFile = null;
			$("#change-img-checkbox").prop("checked",false);
			$("#icon-input").val(null);
			updateImage = false;
			$("#before-upload").show();
			$("#after-upload").hide();
		}
	});
	
	$("#save-img-btn").on("click",function(){
		if(globalFile != null){
			var reader = new FileReader();
		    reader.onload = function(){
			    var dataURL = reader.result;
			    $(".image-view").attr("src",dataURL);
		    };
		    reader.readAsDataURL(globalFile);
		    $("#myModal").modal("hide");
		}
	});
});


function doFormSubmit(){
	//alert("hey");
	alert(isDragNDrop);
	if(updateImage){
		if(isDragNDrop){ //executes if user is uploading image using drag and drop
			//	alert("dropped");
			var formData = new FormData();
			var iconID = $("#icon-id").val();
			formData.append("file",globalFile);
			if(iconID != null && iconID != undefined && iconID.trim().length > 0){
				formData.append("id",iconID);
				$.ajax({
					url: "updateFile",
					data: formData,
					type: "POST",
					processData:false,
					dataType : 'json',
					contentType:false,
					success: function(data) {
						alert("File Updated !") ;
						alert(data);
						alert(data.id);
						document.myForm.submit();
					},
					error: function (xhr, status, error) {
						alert("status "+status);
						return false;
					}
				});
			}else{
				$.ajax({
					url: "createFile",
					data: formData,
					type: "POST",
					processData:false,
					dataType : 'json',
					contentType:false,
					success: function(data) {
						alert("File Updated !") ;
						alert(data);
						alert(data.id);
						$("#icon-id").val(data.id);
						document.myForm.submit();
					},
					error: function (xhr, status, error) {
						alert("status "+status);
						return false;
					}
				});
			}
		}else{ //if user is uploading image using file input
			document.myForm.submit();
		}
	}else{ //if user is uploading image using file input
		document.myForm.submit();
	}
	return false;
}
